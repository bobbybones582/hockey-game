// Procedural audio generator using native Web Audio API for satisfying retro arcade sounds
class AudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  getMuteState() {
    return this.isMuted;
  }

  // Play wooden or ice-puck clack
  playHit() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, this.ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.08);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }

  // Play stick swing / whoosh or power shot launch
  playShoot(power: number = 1) {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = power === 3 ? 'sawtooth' : 'triangle';
      const startFreq = power === 1 ? 120 : power === 2 ? 180 : 320;
      const endFreq = power === 1 ? 440 : power === 2 ? 680 : 1200;
      const duration = power === 1 ? 0.12 : power === 2 ? 0.18 : 0.25;

      osc.frequency.setValueAtTime(startFreq, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(endFreq, this.ctx.currentTime + duration);

      const volume = power === 1 ? 0.1 : power === 2 ? 0.16 : 0.22;
      gain.gain.setValueAtTime(volume, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }

  // Play a metallic resonant CLANG! for hitting the goal post
  playPost() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      
      // Combine multiple high frequencies for realistic metallic chime
      const freqs = [880, 1200, 1500, 2200];
      
      freqs.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        osc.connect(gain);
        gain.connect(this.ctx!.destination);

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        const vol = idx === 0 ? 0.2 : 0.08;
        gain.gain.setValueAtTime(vol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + (idx === 0 ? 0.4 : 0.2));

        osc.start();
        osc.stop(now + (idx === 0 ? 0.4 : 0.2));
      });
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }

  // Play a body check/hit collision (crunchy noise)
  playCheck() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const duration = 0.15;

      // Create synthetic noise buffer for crunch
      const bufferSize = this.ctx.sampleRate * duration;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      // Filter to make it a bassy impact
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(200, now);
      filter.frequency.exponentialRampToValueAtTime(50, now + duration);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start();
      noise.stop(now + duration);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }

  // Play goalie catch/pad save pop
  playSave() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, this.ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.12);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }

  // Play an epic goal celebration whistle and crowd cheer
  playGoal() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;

      // 1. Goal whistle
      const whistle = this.ctx.createOscillator();
      const whistleGain = this.ctx.createGain();
      whistle.connect(whistleGain);
      whistleGain.connect(this.ctx.destination);

      whistle.type = 'sine';
      whistle.frequency.setValueAtTime(800, now);
      whistle.frequency.linearRampToValueAtTime(1200, now + 0.15);
      whistle.frequency.linearRampToValueAtTime(900, now + 0.3);
      whistle.frequency.linearRampToValueAtTime(1400, now + 0.45);

      whistleGain.gain.setValueAtTime(0.12, now);
      whistleGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      whistle.start();
      whistle.stop(now + 0.6);

      // 2. Crowd cheer (Filtered white noise)
      const cheerDuration = 1.8;
      const bufferSize = this.ctx.sampleRate * cheerDuration;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const cheerNode = this.ctx.createBufferSource();
      cheerNode.buffer = buffer;

      const cheerFilter = this.ctx.createBiquadFilter();
      cheerFilter.type = 'bandpass';
      cheerFilter.frequency.setValueAtTime(600, now);
      cheerFilter.Q.setValueAtTime(1.0, now);

      const cheerGain = this.ctx.createGain();
      cheerGain.gain.setValueAtTime(0.25, now);
      cheerGain.gain.exponentialRampToValueAtTime(0.005, now + cheerDuration);

      cheerNode.connect(cheerFilter);
      cheerFilter.connect(cheerGain);
      cheerGain.connect(this.ctx.destination);

      cheerNode.start();
      cheerNode.stop(now + cheerDuration);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  }
}

export const audio = new AudioEngine();
