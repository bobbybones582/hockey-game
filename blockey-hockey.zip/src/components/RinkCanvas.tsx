import React, { useRef, useEffect, useState } from 'react';
import { MatchState, PlayerState, GoalieState, Side, STICK_SKINS, OUTFIT_COLORS, HEADWEAR_OPTIONS } from '../types';
import { RINK_WIDTH, RINK_HEIGHT, GOAL_Y_TOP, GOAL_Y_BOTTOM, GOAL_HEIGHT, GOAL_WIDTH, TOP_WALL, BOTTOM_WALL, LEFT_WALL, RIGHT_WALL } from '../gamePhysics';

interface RinkCanvasProps {
  state: MatchState;
  myPlayerId?: string;
  onCanvasClick?: (e: React.MouseEvent<HTMLCanvasElement>) => void;
  onCanvasRightClick?: (e: React.MouseEvent<HTMLCanvasElement>) => void;
  onMouseMove?: (e: React.MouseEvent<HTMLCanvasElement>) => void;
  cameraMode?: 'first_person' | 'third_person' | 'overhead_3d'; // Ignored, but kept for Prop contract
  onLookAngleChange?: (angle: number) => void;                 // Ignored, but kept for Prop contract
}

interface Particle2D {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  gravity?: number;
}

export const RinkCanvas: React.FC<RinkCanvasProps> = ({
  state,
  myPlayerId,
  onCanvasClick,
  onCanvasRightClick,
  onMouseMove,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Particle list for goal celebrations and ice sprays
  const particlesRef = useRef<Particle2D[]>([]);
  
  // Last puck position to track speed trail
  const lastPuckPosRef = useRef<{ x: number; y: number }>({ x: RINK_WIDTH / 2, y: RINK_HEIGHT / 2 });
  
  // Keep track of goals to trigger explosion
  const lastScoreRef = useRef<{ left: number; right: number }>({ left: 0, right: 0 });

  // Helper lookups for customizable styles
  const getOutfitColor = (outfitId: string) => {
    return OUTFIT_COLORS.find(o => o.id === outfitId) || OUTFIT_COLORS[0];
  };

  const getStickColor = (stickId: string) => {
    return STICK_SKINS.find(s => s.id === stickId) || STICK_SKINS[0];
  };

  const getHeadwear = (headwearId: string) => {
    return HEADWEAR_OPTIONS.find(h => h.id === headwearId) || HEADWEAR_OPTIONS[0];
  };

  // Local helper to spawn 2D sparks/particles
  const spawnExplosion = (x: number, y: number, color: string, count: number = 30) => {
    const list = particlesRef.current;
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 2;
      list.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - (Math.random() * 3 + 1), // bias upwards
        color,
        size: Math.random() * 4 + 2,
        life: 0,
        maxLife: Math.random() * 40 + 30,
        gravity: 0.15,
      });
    }
  };

  // Setup click position conversion
  const handleCanvasMouseClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (onCanvasClick) onCanvasClick(e);
  };

  const handleCanvasMouseRightClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (onCanvasRightClick) onCanvasRightClick(e);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (onMouseMove) onMouseMove(e);
  };

  // Main rendering engine loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    // Detect if score changed to trigger celebration explosion
    if (
      state.score.left !== lastScoreRef.current.left ||
      state.score.right !== lastScoreRef.current.right
    ) {
      if (state.score.left > lastScoreRef.current.left) {
        // Red scored on Blue (Right net)
        spawnExplosion(940, RINK_HEIGHT / 2, '#ef4444', 60);
        spawnExplosion(940, RINK_HEIGHT / 2 - 40, '#f59e0b', 30);
        spawnExplosion(940, RINK_HEIGHT / 2 + 40, '#ffffff', 30);
      } else if (state.score.right > lastScoreRef.current.right) {
        // Blue scored on Red (Left net)
        spawnExplosion(60, RINK_HEIGHT / 2, '#3b82f6', 60);
        spawnExplosion(60, RINK_HEIGHT / 2 - 40, '#10b981', 30);
        spawnExplosion(60, RINK_HEIGHT / 2 + 40, '#ffffff', 30);
      }
      lastScoreRef.current = { left: state.score.left, right: state.score.right };
    }

    const drawFrame = () => {
      // Clear with dark void
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, RINK_WIDTH, RINK_HEIGHT);

      // 1. DRAW SPECTATORS STANDS (Upper & Lower Margins: 0 to 35, 465 to 500)
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, RINK_WIDTH, TOP_WALL);
      ctx.fillRect(0, BOTTOM_WALL, RINK_WIDTH, RINK_HEIGHT - BOTTOM_WALL);

      // Spectators rows
      const isGoalScored = state.status === 'goal_scored';
      const specColors = ['#f43f5e', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ea580c', '#ec4899', '#06b6d4', '#cbd5e1'];
      
      // Upper stand fans
      for (let x = 30; x < RINK_WIDTH; x += 32) {
        const index = Math.floor(x * 17) % specColors.length;
        const color = specColors[index];
        // Bouncing factor
        let bounceY = 0;
        if (isGoalScored) {
          bounceY = Math.sin(Date.now() * 0.016 + x) * 6;
        } else if (Math.hypot(state.puck.vx, state.puck.vy) > 6) {
          bounceY = Math.sin(Date.now() * 0.008 + x) * 2.5;
        }

        // Draw jersey body
        ctx.fillStyle = color;
        ctx.fillRect(x - 8, TOP_WALL - 14 - bounceY, 16, 14);

        // Draw face
        ctx.fillStyle = '#fbcfe8'; // skin tone
        ctx.fillRect(x - 5, TOP_WALL - 22 - bounceY, 10, 8);

        // Small details (cap / eyes)
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(x - 3, TOP_WALL - 20 - bounceY, 2, 2);
        ctx.fillRect(x + 1, TOP_WALL - 20 - bounceY, 2, 2);
      }

      // Lower stand fans
      for (let x = 40; x < RINK_WIDTH; x += 32) {
        const index = Math.floor(x * 23) % specColors.length;
        const color = specColors[index];
        // Bouncing factor
        let bounceY = 0;
        if (isGoalScored) {
          bounceY = Math.sin(Date.now() * 0.016 + x) * 6;
        } else if (Math.hypot(state.puck.vx, state.puck.vy) > 6) {
          bounceY = Math.sin(Date.now() * 0.008 + x) * 2.5;
        }

        // Draw jersey body
        ctx.fillStyle = color;
        ctx.fillRect(x - 8, BOTTOM_WALL + 14 + bounceY, 16, 14);

        // Draw face
        ctx.fillStyle = '#fbcfe8';
        ctx.fillRect(x - 5, BOTTOM_WALL + 6 + bounceY, 10, 8);

        // Eyes
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(x - 3, BOTTOM_WALL + 8 + bounceY, 2, 2);
        ctx.fillRect(x + 1, BOTTOM_WALL + 8 + bounceY, 2, 2);
      }

      // 2. DRAW GLOSSY BLUE ICE RINK
      ctx.fillStyle = '#f0f9ff'; // Clean ice blue background
      ctx.fillRect(LEFT_WALL, TOP_WALL, RIGHT_WALL - LEFT_WALL, BOTTOM_WALL - TOP_WALL);

      // Soft reflection glow gradients
      const reflection = ctx.createRadialGradient(RINK_WIDTH / 2, RINK_HEIGHT / 2, 50, RINK_WIDTH / 2, RINK_HEIGHT / 2, 450);
      reflection.addColorStop(0, 'rgba(255, 255, 255, 0.45)');
      reflection.addColorStop(1, 'rgba(224, 242, 254, 0.1)');
      ctx.fillStyle = reflection;
      ctx.fillRect(LEFT_WALL, TOP_WALL, RIGHT_WALL - LEFT_WALL, BOTTOM_WALL - TOP_WALL);

      // 3. DRAW RINK MARKINGS (Center line, faceoff rings, goal creases)
      // Red Center Line
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(RINK_WIDTH / 2, TOP_WALL);
      ctx.lineTo(RINK_WIDTH / 2, BOTTOM_WALL);
      ctx.stroke();

      // Red Center Circle Ring
      ctx.beginPath();
      ctx.arc(RINK_WIDTH / 2, RINK_HEIGHT / 2, 75, 0, Math.PI * 2);
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
      ctx.stroke();

      // Red Center Dot
      ctx.beginPath();
      ctx.arc(RINK_WIDTH / 2, RINK_HEIGHT / 2, 8, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444';
      ctx.fill();

      // Blue Zone Lines
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(350, TOP_WALL);
      ctx.lineTo(350, BOTTOM_WALL);
      ctx.moveTo(650, TOP_WALL);
      ctx.lineTo(650, BOTTOM_WALL);
      ctx.stroke();

      // Left Goal Crease semicircular zone (At x = 60, y = 250)
      ctx.beginPath();
      ctx.arc(60, RINK_HEIGHT / 2, 50, -Math.PI / 2, Math.PI / 2);
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#0284c7';
      ctx.stroke();
      ctx.fillStyle = 'rgba(14, 165, 233, 0.08)';
      ctx.fill();

      // Right Goal Crease semicircular zone (At x = 940, y = 250)
      ctx.beginPath();
      ctx.arc(940, RINK_HEIGHT / 2, 50, Math.PI / 2, -Math.PI / 2, true);
      ctx.stroke();
      ctx.fill();

      // Red Goal Lines on top of ice (at x = 60 and x = 940)
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(60, GOAL_Y_TOP);
      ctx.lineTo(60, GOAL_Y_BOTTOM);
      ctx.moveTo(940, GOAL_Y_TOP);
      ctx.lineTo(940, GOAL_Y_BOTTOM);
      ctx.stroke();

      // 4. DRAW GOAL NETS FRAME & TRANSPARENT WIREMESH
      // Left Goal (depth from x = 15 to 60)
      ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.fillRect(15, GOAL_Y_TOP, 45, GOAL_Y_BOTTOM - GOAL_Y_TOP);
      // Net stripes
      ctx.strokeStyle = 'rgba(226, 232, 240, 0.25)';
      ctx.lineWidth = 1;
      for (let gy = GOAL_Y_TOP + 10; gy < GOAL_Y_BOTTOM; gy += 10) {
        ctx.beginPath(); ctx.moveTo(15, gy); ctx.lineTo(60, gy); ctx.stroke();
      }
      for (let gx = 25; gx < 60; gx += 10) {
        ctx.beginPath(); ctx.moveTo(gx, GOAL_Y_TOP); ctx.lineTo(gx, GOAL_Y_BOTTOM); ctx.stroke();
      }
      // Red goal posts outer frame border
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 4;
      ctx.strokeRect(15, GOAL_Y_TOP, 45, GOAL_Y_BOTTOM - GOAL_Y_TOP);

      // Right Goal (depth from x = 940 to 985)
      ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.fillRect(940, GOAL_Y_TOP, 45, GOAL_Y_BOTTOM - GOAL_Y_TOP);
      // Net stripes
      ctx.strokeStyle = 'rgba(226, 232, 240, 0.25)';
      ctx.lineWidth = 1;
      for (let gy = GOAL_Y_TOP + 10; gy < GOAL_Y_BOTTOM; gy += 10) {
        ctx.beginPath(); ctx.moveTo(940, gy); ctx.lineTo(985, gy); ctx.stroke();
      }
      for (let gx = 950; gx < 985; gx += 10) {
        ctx.beginPath(); ctx.moveTo(gx, GOAL_Y_TOP); ctx.lineTo(gx, GOAL_Y_BOTTOM); ctx.stroke();
      }
      // Red goal posts outer frame border
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 4;
      ctx.strokeRect(940, GOAL_Y_TOP, 45, GOAL_Y_BOTTOM - GOAL_Y_TOP);

      // 5. DRAW BOARDS / SIDEWALL BOUNDS (Thick oak wood / grey capping)
      ctx.strokeStyle = '#334155'; // Dark slate capping
      ctx.lineWidth = 6;
      ctx.strokeRect(LEFT_WALL, TOP_WALL, RIGHT_WALL - LEFT_WALL, BOTTOM_WALL - TOP_WALL);

      // 6. UPDATE & DRAW 2D ANIMATED PARTICLES (Confetti + snow spray)
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life++;
        p.x += p.vx;
        p.y += p.vy;
        if (p.gravity) {
          p.vy += p.gravity;
        }

        // Apply friction
        p.vx *= 0.98;
        p.vy *= 0.98;

        const opacity = Math.max(0, 1 - p.life / p.maxLife);
        ctx.save();
        ctx.globalAlpha = opacity;
        ctx.fillStyle = p.color;
        // Draw tiny blocky voxel-like confetti squares
        ctx.fillRect(p.x - p.size/2, p.y - p.size/2, p.size, p.size);
        ctx.restore();

        if (p.life >= p.maxLife) {
          particles.splice(i, 1);
        }
      }

      // Puck fast slide spray trail
      const puckVel = Math.hypot(state.puck.vx, state.puck.vy);
      if (puckVel > 4.5 && Math.random() < 0.5) {
        particles.push({
          x: state.puck.x + (Math.random() * 8 - 4),
          y: state.puck.y + (Math.random() * 8 - 4),
          vx: -state.puck.vx * 0.2 + (Math.random() * 2 - 1),
          vy: -state.puck.vy * 0.2 + (Math.random() * 2 - 1),
          color: '#ffffff',
          size: Math.random() * 2.5 + 1,
          life: 0,
          maxLife: 15,
        });
      }

      // 7. DRAW GOALIES
      const drawGoalie = (g: GoalieState) => {
        const sideColor = g.side === 'left' ? '#f97316' : '#a855f7'; // Bulk goalie protector pads

        ctx.save();
        // Goalie block shadow
        ctx.fillStyle = 'rgba(0,0,0,0.2)';
        ctx.beginPath();
        ctx.ellipse(g.x, g.y + g.height/2, g.width * 0.7, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // Protective goalie bulky shoulders (rectangle)
        ctx.fillStyle = sideColor;
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 3.5;
        ctx.fillRect(g.x - g.width/2, g.y - g.height/2, g.width, g.height);
        ctx.strokeRect(g.x - g.width/2, g.y - g.height/2, g.width, g.height);

        // Goalie head
        ctx.fillStyle = '#fbcfe8';
        ctx.fillRect(g.x - 7, g.y - 8, 14, 12);

        // Grid steel face guard mask
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(g.x - 8, g.y - 7, 16, 5);
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(g.x - 5, g.y - 6, 2, 3);
        ctx.fillRect(g.x + 3, g.y - 6, 2, 3);

        // Goalie sticks (drawn in defensive blocking positions)
        ctx.fillStyle = '#b45309';
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 1.5;
        const stickOffset = g.side === 'left' ? 12 : -18;
        ctx.fillRect(g.x + stickOffset, g.y - 12, 6, 26);
        ctx.strokeRect(g.x + stickOffset, g.y - 12, 6, 26);

        // Name tag
        ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
        ctx.roundRect(g.x - 42, g.y - 28, 84, 13, 3);
        ctx.fill();
        ctx.font = 'bold 8px monospace';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(g.side === 'left' ? 'RED GOALIE' : 'BLUE GOALIE', g.x, g.y - 19);

        ctx.restore();
      };

      drawGoalie(state.goalies.left);
      drawGoalie(state.goalies.right);

      // 8. DRAW PLAYERS
      const players = Object.values(state.players);
      players.forEach((p: PlayerState) => {
        const outfit = getOutfitColor(p.skinConfig.outfitId);
        const stick = getStickColor(p.skinConfig.stickId);
        const headwear = getHeadwear(p.skinConfig.headwearId);

        ctx.save();

        // Player shadow
        ctx.fillStyle = 'rgba(0,0,0,0.22)';
        ctx.beginPath();
        ctx.ellipse(p.x, p.y + p.height/2, p.width * 0.75, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        // A. STICK (drawn rotating around player at p.angle)
        ctx.save();
        ctx.translate(p.x, p.y);
        // Swing forward animation offset
        let stickAngleOffset = 0;
        if (p.swingProgress > 0) {
          // Swing forward up to 1.3 radians and release
          stickAngleOffset = Math.sin(p.swingProgress * Math.PI) * 1.35;
        }
        ctx.rotate(p.angle + stickAngleOffset);

        // Stick Glow shadow (for rare skins like netherite, diamond, gold, emerald)
        if (stick.glow) {
          ctx.shadowBlur = 12;
          ctx.shadowColor = stick.glow;
        }

        // Stick Shaft (draw stick stick extend forward on the local canvas)
        ctx.fillStyle = stick.color;
        ctx.strokeStyle = stick.border || '#000000';
        ctx.lineWidth = 1.5;
        // Shaft
        ctx.fillRect(10, -3, 30, 4);
        ctx.strokeRect(10, -3, 30, 4);
        // Stick blade
        ctx.fillRect(36, -3, 4, 12);
        ctx.strokeRect(36, -3, 4, 12);

        ctx.restore();

        // B. AIM-ASSIST DASHED LINE (ONLY for 'me')
        const isMe = p.id === myPlayerId;
        if (isMe) {
          ctx.save();
          ctx.strokeStyle = p.power === 3 ? 'rgba(239, 68, 68, 0.45)' : p.power === 2 ? 'rgba(234, 179, 8, 0.4)' : 'rgba(34, 197, 94, 0.35)';
          ctx.lineWidth = 2.5;
          ctx.setLineDash([6, 6]);
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + Math.cos(p.angle) * 160, p.y + Math.sin(p.angle) * 160);
          ctx.stroke();
          ctx.restore();
        }

        // C. PLAYER VOXEL BODY
        ctx.fillStyle = outfit.primary;
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 3.5;
        ctx.fillRect(p.x - p.width/2, p.y - p.height/2, p.width, p.height);
        ctx.strokeRect(p.x - p.width/2, p.y - p.height/2, p.width, p.height);

        // Jersey Secondary Stripes
        ctx.fillStyle = outfit.secondary;
        ctx.fillRect(p.x - p.width/2 + 2, p.y - p.height/2 + 3, 4, p.height - 6);
        ctx.fillRect(p.x + p.width/2 - 6, p.y - p.height/2 + 3, 4, p.height - 6);

        // D. PLAYER PEACH HEAD BLOCK
        const headSize = 15;
        ctx.fillStyle = '#fbcfe8';
        ctx.fillRect(p.x - headSize/2, p.y - headSize/2 - 2, headSize, headSize);
        ctx.strokeRect(p.x - headSize/2, p.y - headSize/2 - 2, headSize, headSize);

        // Eyes looking towards stick angle
        ctx.fillStyle = '#1e293b';
        const eyeXOffset = Math.cos(p.angle) * 4;
        const eyeYOffset = Math.sin(p.angle) * 4;
        // Two small square eyes
        ctx.fillRect(p.x - 4 + eyeXOffset, p.y - 4 + eyeYOffset, 2.5, 2.5);
        ctx.fillRect(p.x + 1.5 + eyeXOffset, p.y - 4 + eyeYOffset, 2.5, 2.5);

        // E. HEADWEAR SKIN OVERLAY
        if (headwear.id !== 'none') {
          ctx.fillStyle = headwear.color || '#ffffff';
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 1.5;

          if (headwear.renderType === 'helmet') {
            // Draw protective helmet
            ctx.fillRect(p.x - 8, p.y - 12, 16, 8);
            ctx.strokeRect(p.x - 8, p.y - 12, 16, 8);
          } else if (headwear.renderType === 'crown') {
            // Gold Royal crown
            ctx.fillRect(p.x - 8, p.y - 13, 16, 4);
            ctx.beginPath();
            ctx.moveTo(p.x - 8, p.y - 13);
            ctx.lineTo(p.x - 8, p.y - 17);
            ctx.lineTo(p.x - 4, p.y - 13);
            ctx.lineTo(p.x, p.y - 18);
            ctx.lineTo(p.x + 4, p.y - 13);
            ctx.lineTo(p.x + 8, p.y - 17);
            ctx.lineTo(p.x + 8, p.y - 13);
            ctx.fill();
            ctx.stroke();
          } else if (headwear.renderType === 'cap') {
            // Visor cap
            ctx.fillRect(p.x - 8, p.y - 12, 16, 5);
            ctx.strokeRect(p.x - 8, p.y - 12, 16, 5);
            // Brim facing look angle
            const capBrimX = Math.cos(p.angle) * 6;
            const capBrimY = Math.sin(p.angle) * 6;
            ctx.fillRect(p.x - 3 + capBrimX, p.y - 9 + capBrimY, 6, 2.5);
          } else if (headwear.renderType === 'headband') {
            // Ninja band wrap
            ctx.fillStyle = headwear.color || '#ef4444';
            ctx.fillRect(p.x - 8, p.y - 7, 16, 3);
            ctx.strokeRect(p.x - 8, p.y - 7, 16, 3);
          }
        }

        // F. SHOOT POWER BATTERY GAUGE (Pip indicator above player name)
        const powerColor = p.power === 3 ? '#ef4444' : p.power === 2 ? '#fbbf24' : '#22c55e';
        ctx.fillStyle = 'rgba(15, 23, 42, 0.8)';
        ctx.roundRect(p.x - 20, p.y - 25, 40, 6, 2);
        ctx.fill();
        ctx.fillStyle = powerColor;
        const fillWidth = (p.power / 3) * 36;
        ctx.fillRect(p.x - 18, p.y - 24, fillWidth, 4);

        // G. FLOATING PLAYER NAME BADGE
        ctx.fillStyle = isMe ? 'rgba(8, 145, 178, 0.85)' : 'rgba(15, 23, 42, 0.7)';
        ctx.roundRect(p.x - 45, p.y - 41, 90, 13, 3);
        ctx.fill();
        ctx.strokeStyle = isMe ? '#22d3ee' : p.side === 'left' ? '#f43f5e' : '#3b82f6';
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.font = 'bold 9px monospace';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.fillText(p.name.toUpperCase() + (isMe ? ' (ME)' : ''), p.x, p.y - 32);

        ctx.restore();
      });

      // 9. DRAW THE PUCK
      const puck = state.puck;
      ctx.save();
      
      // Puck Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.22)';
      ctx.beginPath();
      ctx.arc(puck.x + 2, puck.y + 4, puck.radius, 0, Math.PI * 2);
      ctx.fill();

      // Puck Core Circle
      ctx.fillStyle = '#0f172a'; // solid midnight slab
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(puck.x, puck.y, puck.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Inner puck gloss grid circle
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(puck.x, puck.y, puck.radius - 3, 0, Math.PI * 2);
      ctx.stroke();

      ctx.restore();

      // Loop rendering frames
      animId = requestAnimationFrame(drawFrame);
    };

    drawFrame();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [state, myPlayerId]);

  return (
    <div className="w-full aspect-[2/1] max-h-[460px] bg-slate-950 border-4 border-slate-800 rounded-2xl relative overflow-hidden select-none flex items-center justify-center">
      {/* 2D HTML5 Responsive Scalable Canvas */}
      <canvas
        ref={canvasRef}
        id="hockey-rink-canvas"
        width={RINK_WIDTH}
        height={RINK_HEIGHT}
        className="w-full h-full object-contain cursor-crosshair bg-slate-950"
        onClick={handleCanvasMouseClick}
        onContextMenu={handleCanvasMouseRightClick}
        onMouseMove={handleCanvasMouseMove}
      />

      {/* FLOATY RETRO GAME BADGES OVERLAY */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 pointer-events-none font-mono">
        <div className="bg-slate-950/90 border border-slate-700/80 px-3 py-1 rounded-lg shadow-lg flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-[10px] text-slate-400 tracking-wider uppercase font-bold">2D MODE:</span>
          <span className="text-xs font-black text-cyan-300">ACTIVE</span>
        </div>
      </div>

      {/* Warmup Countdown Banner */}
      {state.status === 'warmup' && (
        <div className="absolute top-4 right-4 bg-yellow-500/10 border border-yellow-500/30 px-3 py-1.5 rounded-lg font-mono pointer-events-none text-right z-10 shadow-md">
          <span className="text-[9px] text-yellow-400 uppercase tracking-wider block font-bold">Match Warmup:</span>
          <span className="text-xs text-white font-black">READY IN: {Math.ceil(state.resetTimer)}s</span>
        </div>
      )}

      {/* Lobby Queue Alert */}
      {state.status === 'lobby' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-sm pointer-events-none font-mono z-10">
          <span className="text-cyan-400 text-sm animate-pulse font-bold">WAITING FOR OPPONENT...</span>
        </div>
      )}
    </div>
  );
};
