import React, { useRef, useEffect } from 'react';
import { SkinConfig, STICK_SKINS, OUTFIT_COLORS, HEADWEAR_OPTIONS } from '../types';

interface CharacterPreviewProps {
  skinConfig: SkinConfig;
  name: string;
}

export const CharacterPreview: React.FC<CharacterPreviewProps> = ({ skinConfig, name }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    
    const render = () => {
      ctx.clearRect(0, 0, 150, 150);

      const px = 75;
      const py = 75;
      const size = 50;
      const half = size / 2;

      // Draw shadow
      ctx.fillStyle = 'rgba(15, 23, 42, 0.15)';
      ctx.fillRect(px - half + 5, py - half + 5, size, size);

      // Get colors and textures
      const outfit = OUTFIT_COLORS.find(o => o.id === skinConfig.outfitId) || OUTFIT_COLORS[0];
      const stick = STICK_SKINS.find(s => s.id === skinConfig.stickId) || STICK_SKINS[0];
      const headwear = HEADWEAR_OPTIONS.find(h => h.id === skinConfig.headwearId) || HEADWEAR_OPTIONS[0];

      // Draw Jersey Base
      ctx.fillStyle = outfit.primary;
      ctx.fillRect(px - half, py - half, size, size);

      // Jersey stripe details
      ctx.fillStyle = outfit.secondary;
      ctx.fillRect(px - half + 8, py - half, 8, size);
      ctx.fillRect(px + half - 16, py - half, 8, size);

      // Border outline
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 4;
      ctx.strokeRect(px - half, py - half, size, size);

      // Face rect (Minecraft style peach block)
      ctx.fillStyle = '#fbcfe8';
      const faceW = 20;
      const faceH = 12;
      ctx.fillRect(px - faceW / 2, py - faceH / 2, faceW, faceH);

      // Eyes
      ctx.fillStyle = '#000000';
      ctx.fillRect(px - 6, py - 2, 4, 4);
      ctx.fillRect(px + 2, py - 2, 4, 4);

      // Headwear
      if (headwear && headwear.id !== 'none') {
        ctx.fillStyle = headwear.color || '#ffffff';
        
        if (headwear.renderType === 'helmet') {
          // Iron/Gold/Diamond bucket helmet
          ctx.fillRect(px - half - 2, py - half - 4, size + 4, 20);
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(px - half, py - half + 12, size, 4);
        } else if (headwear.renderType === 'crown') {
          // Royal Crown
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(px - half, py - half - 6, size, 6);
          ctx.beginPath();
          ctx.moveTo(px - half, py - half - 6);
          ctx.lineTo(px - half + 8, py - half - 18);
          ctx.lineTo(px - half + 16, py - half - 6);
          ctx.lineTo(px, py - half - 20);
          ctx.lineTo(px + half - 16, py - half - 6);
          ctx.lineTo(px + half - 8, py - half - 18);
          ctx.lineTo(px + half, py - half - 6);
          ctx.closePath();
          ctx.fill();
        } else if (headwear.renderType === 'cap') {
          // Cap
          ctx.fillRect(px - half - 2, py - half - 4, size + 4, 10);
          ctx.fillRect(px + 4, py - half + 2, 22, 6); // Brim
        } else if (headwear.renderType === 'headband') {
          // Headband
          ctx.fillStyle = headwear.color || '#ef4444';
          ctx.fillRect(px - half - 2, py - half + 4, size + 4, 8);
        }
      }

      // Draw Hockey Stick (Slow rotational hover animation)
      ctx.save();
      ctx.translate(px, py);
      
      const hoverAngle = Math.sin(Date.now() * 0.003) * 0.35 + 0.5;
      ctx.rotate(hoverAngle);

      if (stick.glow) {
        ctx.shadowColor = stick.color;
        ctx.shadowBlur = 10;
      }

      // Stick shaft
      ctx.fillStyle = '#d1fae5'; // tape
      ctx.fillRect(10, -5, 20, 10);
      ctx.fillStyle = stick.color;
      ctx.fillRect(30, -5, 30, 10);

      // Stick blade tip
      ctx.fillRect(60, -5, 10, 24);

      // Border outline on stick
      ctx.strokeStyle = stick.border || '#1e293b';
      ctx.lineWidth = 2;
      ctx.strokeRect(30, -5, 30, 10);
      ctx.strokeRect(60, -5, 10, 24);

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animId);
  }, [skinConfig]);

  return (
    <div className="flex flex-col items-center justify-center p-3 border-2 border-slate-700 bg-slate-900 rounded-lg shadow-inner">
      <canvas ref={canvasRef} width={150} height={150} className="mb-2 bg-slate-800 rounded border border-slate-700 shadow" />
      <span className="font-mono text-sm font-semibold tracking-wider text-cyan-400 max-w-[140px] truncate">
        {name || 'Player'}
      </span>
    </div>
  );
};
