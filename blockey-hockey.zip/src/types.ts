export type Side = 'left' | 'right';

export interface StickSkin {
  id: string;
  name: string;
  color: string;
  glow?: string;
  border?: string;
}

export interface OutfitColor {
  id: string;
  name: string;
  primary: string;
  secondary: string;
}

export interface Headwear {
  id: string;
  name: string;
  emoji?: string;
  renderType?: 'helmet' | 'crown' | 'cap' | 'headband' | 'none';
  color?: string;
}

export interface SkinConfig {
  stickId: string;
  outfitId: string;
  headwearId: string;
}

export interface PlayerStats {
  goals: number;
  shotsOnGoal: number;
  saves: number;
  checks: number; // Hits on opponent
  powerShots: number;
}

export interface PlayerState {
  id: string;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  side: Side;
  power: number; // 1, 2, or 3
  skinConfig: SkinConfig;
  stats: PlayerStats;
  isReady: boolean;
  angle: number; // Stick angle in radians
  swingProgress: number; // 0 to 1 for stick swing animation
  isOnline: boolean;
}

export interface PuckState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  lastTouchedById: string | null;
}

export interface GoalieState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  side: Side;
}

export interface MatchState {
  roomId: string;
  players: { [id: string]: PlayerState };
  puck: PuckState;
  goalies: {
    left: GoalieState;
    right: GoalieState;
  };
  score: {
    left: number;
    right: number;
  };
  timeLeft: number; // In seconds
  status: 'lobby' | 'warmup' | 'playing' | 'goal_scored' | 'ended';
  goalScoredTeam: Side | null;
  resetTimer: number; // Countdown after goal scored
  winnerId: string | null;
  gameMode: 'practice' | 'local' | 'online';
}

// Pre-defined Customization Assets
export const STICK_SKINS: StickSkin[] = [
  { id: 'wood', name: 'Classic Wooden', color: '#8B5A2B', border: '#5C3A21' },
  { id: 'stone', name: 'Cobblestone', color: '#708090', border: '#4F4F4F' },
  { id: 'iron', name: 'Refined Iron', color: '#D3D3D3', border: '#A9A9A9' },
  { id: 'gold', name: 'Glistering Gold', color: '#FFD700', border: '#DAA520', glow: 'rgba(255, 215, 0, 0.5)' },
  { id: 'diamond', name: 'Mystic Diamond', color: '#00FFFF', border: '#008B8B', glow: 'rgba(0, 255, 255, 0.6)' },
  { id: 'netherite', name: 'Netherite', color: '#312A2F', border: '#1C151B', glow: 'rgba(128, 0, 128, 0.4)' },
  { id: 'emerald', name: 'Emerald', color: '#50C878', border: '#2E8B57', glow: 'rgba(80, 200, 120, 0.5)' },
];

export const OUTFIT_COLORS: OutfitColor[] = [
  { id: 'red', name: 'Red Team', primary: '#DC2626', secondary: '#991B1B' },
  { id: 'blue', name: 'Blue Team', primary: '#2563EB', secondary: '#1E40AF' },
  { id: 'green', name: 'Creeper Green', primary: '#16A34A', secondary: '#166534' },
  { id: 'yellow', name: 'Lapis Gold', primary: '#EAB308', secondary: '#A16207' },
  { id: 'purple', name: 'Ender Purple', primary: '#9333EA', secondary: '#6B21A8' },
  { id: 'orange', name: 'Magma Orange', primary: '#EA580C', secondary: '#9A3412' },
];

export const HEADWEAR_OPTIONS: Headwear[] = [
  { id: 'none', name: 'No Headwear', renderType: 'none' },
  { id: 'helmet_iron', name: 'Iron Helmet', renderType: 'helmet', color: '#E5E7EB' },
  { id: 'helmet_gold', name: 'Gold Helmet', renderType: 'helmet', color: '#FCD34D' },
  { id: 'helmet_diamond', name: 'Diamond Helmet', renderType: 'helmet', color: '#67E8F9' },
  { id: 'crown', name: 'Royal Crown', renderType: 'crown', color: '#FBBF24' },
  { id: 'cap', name: 'Steve\'s Cap', renderType: 'cap', color: '#3B82F6' },
  { id: 'headband', name: 'Ninja Headband', renderType: 'headband', color: '#EF4444' },
];
