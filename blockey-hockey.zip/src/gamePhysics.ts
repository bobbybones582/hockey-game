import { MatchState, PlayerState, PuckState, GoalieState, Side, SkinConfig } from './types';

export const RINK_WIDTH = 1000;
export const RINK_HEIGHT = 500;

export const TOP_WALL = 35;
export const BOTTOM_WALL = 465;
export const LEFT_WALL = 15;
export const RIGHT_WALL = 985;

// Goal Box Dimensions
export const GOAL_WIDTH = 45; // Depth
export const GOAL_HEIGHT = 130; // Height (span y = 185 to 315)
export const GOAL_Y_TOP = 185;
export const GOAL_Y_BOTTOM = 315;

export const PLAYER_SIZE = 26;
export const GOALIE_SIZE = 30;
export const PUCK_RADIUS = 9;

// Physics constants
export const PLAYER_ACCEL = 0.45;
export const PLAYER_FRICTION = 0.94;
export const PLAYER_MAX_SPEED = 5.2;

export const PUCK_FRICTION = 0.988; // Ice friction
export const PUCK_BOUNCE = 0.85;

export const GOALIE_SPEED = 3.2;

export function createInitialPuck(): PuckState {
  return {
    x: RINK_WIDTH / 2,
    y: RINK_HEIGHT / 2,
    vx: 0,
    vy: 0,
    radius: PUCK_RADIUS,
    lastTouchedById: null,
  };
}

export function createInitialGoalie(side: Side): GoalieState {
  return {
    x: side === 'left' ? 65 : 935,
    y: RINK_HEIGHT / 2,
    vx: 0,
    vy: 0,
    width: GOALIE_SIZE,
    height: GOALIE_SIZE,
    side,
  };
}

export function createPlayer(id: string, name: string, side: Side, skinConfig: SkinConfig, isOnline: boolean = false): PlayerState {
  return {
    id,
    name,
    x: side === 'left' ? 250 : 750,
    y: RINK_HEIGHT / 2,
    vx: 0,
    vy: 0,
    width: PLAYER_SIZE,
    height: PLAYER_SIZE,
    side,
    power: 1,
    skinConfig,
    stats: {
      goals: 0,
      shotsOnGoal: 0,
      saves: 0,
      checks: 0,
      powerShots: 0,
    },
    isReady: false,
    angle: side === 'left' ? 0 : Math.PI,
    swingProgress: 0,
    isOnline,
  };
}

export function resetPositions(state: MatchState) {
  state.puck = createInitialPuck();
  
  // Reset players
  Object.values(state.players).forEach(p => {
    p.x = p.side === 'left' ? 250 : 750;
    p.y = RINK_HEIGHT / 2;
    p.vx = 0;
    p.vy = 0;
    p.angle = p.side === 'left' ? 0 : Math.PI;
    p.swingProgress = 0;
  });

  // Reset goalies
  state.goalies.left = createInitialGoalie('left');
  state.goalies.right = createInitialGoalie('right');
}

// Axis-Aligned Bounding Box (AABB) intersection check
function checkAABBCollision(
  x1: number, y1: number, w1: number, h1: number,
  x2: number, y2: number, w2: number, h2: number
) {
  return (
    x1 - w1/2 < x2 + w2/2 &&
    x1 + w1/2 > x2 - w2/2 &&
    y1 - h1/2 < y2 + h2/2 &&
    y1 + h1/2 > y2 - h2/2
  );
}

// Resolve player bounding box with goals
function resolvePlayerWithGoalNets(p: { x: number, y: number, vx: number, vy: number }) {
  const half = PLAYER_SIZE / 2;

  // Left net box: x: 15..60, y: 185..315
  const leftNetXStart = 15;
  const leftNetXEnd = 60;
  if (p.x + half > leftNetXStart && p.x - half < leftNetXEnd && p.y + half > GOAL_Y_TOP && p.y - half < GOAL_Y_BOTTOM) {
    // Collides. Push player out
    const distToRight = Math.abs((p.x - half) - leftNetXEnd);
    const distToTop = Math.abs((p.y + half) - GOAL_Y_TOP);
    const distToBottom = Math.abs((p.y - half) - GOAL_Y_BOTTOM);
    const distToLeft = Math.abs((p.x + half) - leftNetXStart);

    const minDist = Math.min(distToRight, distToTop, distToBottom, distToLeft);
    if (minDist === distToRight) {
      p.x = leftNetXEnd + half;
      p.vx = Math.max(0, p.vx);
    } else if (minDist === distToTop) {
      p.y = GOAL_Y_TOP - half;
      p.vy = Math.min(0, p.vy);
    } else if (minDist === distToBottom) {
      p.y = GOAL_Y_BOTTOM + half;
      p.vy = Math.max(0, p.vy);
    } else if (minDist === distToLeft) {
      p.x = leftNetXStart - half;
      p.vx = Math.min(0, p.vx);
    }
  }

  // Right net box: x: 940..985, y: 185..315
  const rightNetXStart = 940;
  const rightNetXEnd = 985;
  if (p.x + half > rightNetXStart && p.x - half < rightNetXEnd && p.y + half > GOAL_Y_TOP && p.y - half < GOAL_Y_BOTTOM) {
    // Collides. Push player out
    const distToLeft = Math.abs((p.x + half) - rightNetXStart);
    const distToTop = Math.abs((p.y + half) - GOAL_Y_TOP);
    const distToBottom = Math.abs((p.y - half) - GOAL_Y_BOTTOM);
    const distToRight = Math.abs((p.x - half) - rightNetXEnd);

    const minDist = Math.min(distToLeft, distToTop, distToBottom, distToRight);
    if (minDist === distToLeft) {
      p.x = rightNetXStart - half;
      p.vx = Math.min(0, p.vx);
    } else if (minDist === distToTop) {
      p.y = GOAL_Y_TOP - half;
      p.vy = Math.min(0, p.vy);
    } else if (minDist === distToBottom) {
      p.y = GOAL_Y_BOTTOM + half;
      p.vy = Math.max(0, p.vy);
    } else if (minDist === distToRight) {
      p.x = rightNetXEnd + half;
      p.vx = Math.max(0, p.vx);
    }
  }
}

// Tick-based physics updates
export function updatePhysics(
  state: MatchState,
  inputs: { [id: string]: { dx: number; dy: number; angle: number; isSwinging: boolean; power: number } },
  onSoundTrigger?: (soundType: 'hit' | 'shoot' | 'goal' | 'post' | 'check' | 'save') => void
) {
  if (state.status === 'ended') return;

  // Countdown timers
  if (state.status === 'goal_scored') {
    state.resetTimer -= 0.02;
    if (state.resetTimer <= 0) {
      state.status = 'playing';
      resetPositions(state);
    }
  }

  if (state.status === 'warmup') {
    state.resetTimer -= 0.02;
    if (state.resetTimer <= 0) {
      state.status = 'playing';
      resetPositions(state);
    }
  }

  // Update game clock (if in playing mode)
  if (state.status === 'playing') {
    state.timeLeft = Math.max(0, state.timeLeft - 0.02);
    if (state.timeLeft <= 0) {
      state.status = 'ended';
      
      // Determine winner
      const leftScore = state.score.left;
      const rightScore = state.score.right;
      if (leftScore > rightScore) {
        const leftPlayer = Object.values(state.players).find(p => p.side === 'left');
        state.winnerId = leftPlayer ? leftPlayer.id : 'left_team';
      } else if (rightScore > leftScore) {
        const rightPlayer = Object.values(state.players).find(p => p.side === 'right');
        state.winnerId = rightPlayer ? rightPlayer.id : 'right_team';
      } else {
        state.winnerId = 'tie';
      }
    }
  }

  // 1. PLAYERS PHYSICS
  const pList = Object.values(state.players);
  pList.forEach(p => {
    const input = inputs[p.id] || { dx: 0, dy: 0, angle: p.angle, isSwinging: false, power: p.power };
    
    p.power = input.power;
    p.angle = input.angle;

    // Movement speeds & limits (Power 3 slows player slightly)
    const currentMaxSpeed = p.power === 3 ? PLAYER_MAX_SPEED * 0.75 : PLAYER_MAX_SPEED;

    // Acceleration
    if (input.dx !== 0) p.vx += input.dx * PLAYER_ACCEL;
    if (input.dy !== 0) p.vy += input.dy * PLAYER_ACCEL;

    // Ice drag
    p.vx *= PLAYER_FRICTION;
    p.vy *= PLAYER_FRICTION;

    // Speed Clamp
    const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
    if (speed > currentMaxSpeed) {
      p.vx = (p.vx / speed) * currentMaxSpeed;
      p.vy = (p.vy / speed) * currentMaxSpeed;
    }

    // Position integration
    p.x += p.vx;
    p.y += p.vy;

    // Bounds check
    const half = p.width / 2;
    if (p.x - half < LEFT_WALL) { p.x = LEFT_WALL + half; p.vx = 0; }
    if (p.x + half > RIGHT_WALL) { p.x = RIGHT_WALL - half; p.vx = 0; }
    if (p.y - half < TOP_WALL) { p.y = TOP_WALL + half; p.vy = 0; }
    if (p.y + half > BOTTOM_WALL) { p.y = BOTTOM_WALL - half; p.vy = 0; }

    // Net collisons
    resolvePlayerWithGoalNets(p);

    // Stick swing progress
    if (input.isSwinging && p.swingProgress === 0) {
      p.swingProgress = 0.05;
      if (onSoundTrigger) onSoundTrigger('shoot');
    }

    if (p.swingProgress > 0) {
      p.swingProgress += 0.15; // Animation speed
      if (p.swingProgress >= 1.0) {
        p.swingProgress = 0;
      }
    }
  });

  // Player-Player Collisions (Body checking!)
  for (let i = 0; i < pList.length; i++) {
    for (let j = i + 1; j < pList.length; j++) {
      const p1 = pList[i];
      const p2 = pList[j];
      const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
      const minDist = PLAYER_SIZE;

      if (dist < minDist) {
        // Simple circle collision representation to push apart smoothly
        const overlap = minDist - dist;
        const nx = (p1.x - p2.x) / (dist || 1);
        const ny = (p1.y - p2.y) / (dist || 1);

        // Push apart
        p1.x += nx * overlap * 0.5;
        p1.y += ny * overlap * 0.5;
        p2.x -= nx * overlap * 0.5;
        p2.y -= ny * overlap * 0.5;

        // Bounce velocities slightly
        const tempVx = p1.vx;
        const tempVy = p1.vy;
        p1.vx = p2.vx * 0.5 + nx * 1.5;
        p1.vy = p2.vy * 0.5 + ny * 1.5;
        p2.vx = tempVx * 0.5 - nx * 1.5;
        p2.vy = tempVy * 0.5 - ny * 1.5;

        // Body checking counts
        if (Math.hypot(p1.vx - p2.vx, p1.vy - p2.vy) > 3) {
          p1.stats.checks += 1;
          p2.stats.checks += 1;
          if (onSoundTrigger) onSoundTrigger('check');
        }
      }
    }
  }

  // 2. GOALIE PHYSICS & AI (Synchronized on Server/Client)
  const gList = [state.goalies.left, state.goalies.right];
  gList.forEach(g => {
    // Goalie simple AI: Move up/down to stay lined up with puck
    const targetY = state.puck.y;
    const goalieCenterY = g.y;
    const dy = targetY - goalieCenterY;

    // Only react if within tracking limits
    if (Math.abs(dy) > 10) {
      const dir = Math.sign(dy);
      g.vy = dir * GOALIE_SPEED;
    } else {
      g.vy *= 0.6; // Damping
    }

    g.y += g.vy;

    // Clamp Goalie inside the goal line vertical constraints (y: 195 to 305)
    const goalieMinY = GOAL_Y_TOP + g.height / 2 + 5;
    const goalieMaxY = GOAL_Y_BOTTOM - g.height / 2 - 5;
    if (g.y < goalieMinY) { g.y = goalieMinY; g.vy = 0; }
    if (g.y > goalieMaxY) { g.y = goalieMaxY; g.vy = 0; }
  });

  // 3. PUCK PHYSICS
  const puck = state.puck;
  puck.x += puck.vx;
  puck.y += puck.vy;
  puck.vx *= PUCK_FRICTION;
  puck.vy *= PUCK_FRICTION;

  // Outer bounds & bounces for Puck
  if (puck.y - puck.radius < TOP_WALL) {
    puck.y = TOP_WALL + puck.radius;
    puck.vy = -puck.vy * PUCK_BOUNCE;
    if (onSoundTrigger) onSoundTrigger('hit');
  }
  if (puck.y + puck.radius > BOTTOM_WALL) {
    puck.y = BOTTOM_WALL - puck.radius;
    puck.vy = -puck.vy * PUCK_BOUNCE;
    if (onSoundTrigger) onSoundTrigger('hit');
  }

  // End boards (outside goals)
  if (puck.x - puck.radius < LEFT_WALL) {
    if (puck.y < GOAL_Y_TOP || puck.y > GOAL_Y_BOTTOM) {
      puck.x = LEFT_WALL + puck.radius;
      puck.vx = -puck.vx * PUCK_BOUNCE;
      if (onSoundTrigger) onSoundTrigger('hit');
    }
  }
  if (puck.x + puck.radius > RIGHT_WALL) {
    if (puck.y < GOAL_Y_TOP || puck.y > GOAL_Y_BOTTOM) {
      puck.x = RIGHT_WALL - puck.radius;
      puck.vx = -puck.vx * PUCK_BOUNCE;
      if (onSoundTrigger) onSoundTrigger('hit');
    }
  }

  // Puck collision with outer walls of LEFT net (Top and Bottom sides)
  if (puck.x >= 15 && puck.x <= 60) {
    if (puck.y < GOAL_Y_TOP) {
      if (puck.y + puck.radius > GOAL_Y_TOP) {
        puck.y = GOAL_Y_TOP - puck.radius;
        puck.vy = -puck.vy * PUCK_BOUNCE;
        if (onSoundTrigger) onSoundTrigger('hit');
      }
    } else if (puck.y > GOAL_Y_BOTTOM) {
      if (puck.y - puck.radius < GOAL_Y_BOTTOM) {
        puck.y = GOAL_Y_BOTTOM + puck.radius;
        puck.vy = -puck.vy * PUCK_BOUNCE;
        if (onSoundTrigger) onSoundTrigger('hit');
      }
    }
  }

  // Puck collision with outer walls of RIGHT net (Top and Bottom sides)
  if (puck.x >= 940 && puck.x <= 985) {
    if (puck.y < GOAL_Y_TOP) {
      if (puck.y + puck.radius > GOAL_Y_TOP) {
        puck.y = GOAL_Y_TOP - puck.radius;
        puck.vy = -puck.vy * PUCK_BOUNCE;
        if (onSoundTrigger) onSoundTrigger('hit');
      }
    } else if (puck.y > GOAL_Y_BOTTOM) {
      if (puck.y - puck.radius < GOAL_Y_BOTTOM) {
        puck.y = GOAL_Y_BOTTOM + puck.radius;
        puck.vy = -puck.vy * PUCK_BOUNCE;
        if (onSoundTrigger) onSoundTrigger('hit');
      }
    }
  }

  // Goals inner wall reflections & Score check
  // Left Goal Box: x: 15..60 (inside depth), y: 185..315 (net area)
  if (puck.x < 60 && puck.y > GOAL_Y_TOP && puck.y < GOAL_Y_BOTTOM) {
    // If puck passes goal line going left
    if (state.status === 'playing' && puck.x <= 55) {
      // GOAL FOR RIGHT TEAM!
      state.score.right += 1;
      state.status = 'goal_scored';
      state.goalScoredTeam = 'right';
      state.resetTimer = 3.0; // 3 seconds goal celebration
      
      // Update scoring stats
      const scorer = Object.values(state.players).find(p => p.side === 'right');
      if (scorer && puck.lastTouchedById === scorer.id) {
        scorer.stats.goals += 1;
      } else if (scorer) {
        // fallback goal credit
        scorer.stats.goals += 1;
      }
      if (onSoundTrigger) onSoundTrigger('goal');
    }

    // Bounce off inner walls of LEFT goal
    if (puck.x < LEFT_WALL + puck.radius) {
      puck.x = LEFT_WALL + puck.radius;
      puck.vx = -puck.vx * PUCK_BOUNCE;
    }
    if (puck.y - puck.radius < GOAL_Y_TOP) {
      puck.y = GOAL_Y_TOP + puck.radius;
      puck.vy = -puck.vy * PUCK_BOUNCE;
    }
    if (puck.y + puck.radius > GOAL_Y_BOTTOM) {
      puck.y = GOAL_Y_BOTTOM - puck.radius;
      puck.vy = -puck.vy * PUCK_BOUNCE;
    }
  }

  // Right Goal Box: x: 940..985, y: 185..315
  if (puck.x > 940 && puck.y > GOAL_Y_TOP && puck.y < GOAL_Y_BOTTOM) {
    // If puck passes goal line going right
    if (state.status === 'playing' && puck.x >= 945) {
      // GOAL FOR LEFT TEAM!
      state.score.left += 1;
      state.status = 'goal_scored';
      state.goalScoredTeam = 'left';
      state.resetTimer = 3.0; // 3 seconds celebration
      
      // Update scoring stats
      const scorer = Object.values(state.players).find(p => p.side === 'left');
      if (scorer && puck.lastTouchedById === scorer.id) {
        scorer.stats.goals += 1;
      } else if (scorer) {
        scorer.stats.goals += 1;
      }
      if (onSoundTrigger) onSoundTrigger('goal');
    }

    // Bounce off inner walls of RIGHT goal
    if (puck.x > RIGHT_WALL - puck.radius) {
      puck.x = RIGHT_WALL - puck.radius;
      puck.vx = -puck.vx * PUCK_BOUNCE;
    }
    if (puck.y - puck.radius < GOAL_Y_TOP) {
      puck.y = GOAL_Y_TOP + puck.radius;
      puck.vy = -puck.vy * PUCK_BOUNCE;
    }
    if (puck.y + puck.radius > GOAL_Y_BOTTOM) {
      puck.y = GOAL_Y_BOTTOM - puck.radius;
      puck.vy = -puck.vy * PUCK_BOUNCE;
    }
  }

  // Goal Post Collision (Circle-Circle Ricochets!)
  // Goal posts centers:
  const posts = [
    { x: 60, y: GOAL_Y_TOP },
    { x: 60, y: GOAL_Y_BOTTOM },
    { x: 940, y: GOAL_Y_TOP },
    { x: 940, y: GOAL_Y_BOTTOM }
  ];
  posts.forEach(post => {
    const dx = puck.x - post.x;
    const dy = puck.y - post.y;
    const dist = Math.hypot(dx, dy);
    const minDist = puck.radius + 6; // Goalpost radius is 6

    if (dist < minDist) {
      // Collide puck off the post circular cap!
      const overlap = minDist - dist;
      const nx = dx / (dist || 1);
      const ny = dy / (dist || 1);

      puck.x += nx * overlap;
      puck.y += ny * overlap;

      // Reflect puck velocity with post restitution
      const dot = puck.vx * nx + puck.vy * ny;
      puck.vx = (puck.vx - 2 * dot * nx) * PUCK_BOUNCE;
      puck.vy = (puck.vy - 2 * dot * ny) * PUCK_BOUNCE;
      
      if (onSoundTrigger) onSoundTrigger('post');
    }
  });

  // 4. PUCK-PLAYER COLLISIONS
  pList.forEach(p => {
    const dx = puck.x - p.x;
    const dy = puck.y - p.y;
    const dist = Math.hypot(dx, dy);
    const playerRadius = PLAYER_SIZE / 2;
    const collisionDist = playerRadius + puck.radius;

    if (dist < collisionDist) {
      // Resolve overlapping
      const overlap = collisionDist - dist;
      const nx = dx / (dist || 1);
      const ny = dy / (dist || 1);

      puck.x += nx * overlap;
      puck.y += ny * overlap;

      // Impart player velocity + pushing force
      puck.vx = puck.vx * 0.4 + p.vx * 0.6 + nx * 1.8;
      puck.vy = puck.vy * 0.4 + p.vy * 0.6 + ny * 1.8;
      
      puck.lastTouchedById = p.id;
      if (onSoundTrigger) onSoundTrigger('hit');
    }

    // Stick swing puck shooting check!
    // Active swing impact frame: swingProgress is between 0.1 and 0.8
    if (p.swingProgress > 0.05 && p.swingProgress < 0.8) {
      // Find stick tip location
      const STICK_LENGTH = 36;
      const stickTipX = p.x + Math.cos(p.angle) * STICK_LENGTH;
      const stickTipY = p.y + Math.sin(p.angle) * STICK_LENGTH;
      const distToTip = Math.hypot(puck.x - stickTipX, puck.y - stickTipY);

      // If puck is close to stick tip or sweep radius
      if (distToTip < 30 || dist < 45) {
        // Swing Hit!
        let shootForce = 8;
        if (p.power === 2) shootForce = 13.5;
        if (p.power === 3) shootForce = 21.0;

        puck.vx = Math.cos(p.angle) * shootForce;
        puck.vy = Math.sin(p.angle) * shootForce;
        
        puck.lastTouchedById = p.id;

        // Stats tracking
        p.stats.shotsOnGoal += 1;
        if (p.power === 3) p.stats.powerShots += 1;

        // Reset swing progress so we only trigger once per swing
        p.swingProgress = 0.8; 
        
        if (onSoundTrigger) onSoundTrigger('shoot');
      }
    }
  });

  // 5. PUCK-GOALIE COLLISIONS (AI Saves!)
  const goalies = [state.goalies.left, state.goalies.right];
  goalies.forEach(g => {
    const dx = puck.x - g.x;
    const dy = puck.y - g.y;
    const dist = Math.hypot(dx, dy);
    const goalieRadius = GOALIE_SIZE / 2;
    const collisionDist = goalieRadius + puck.radius;

    if (dist < collisionDist) {
      const overlap = collisionDist - dist;
      const nx = dx / (dist || 1);
      const ny = dy / (dist || 1);

      puck.x += nx * overlap;
      puck.y += ny * overlap;

      // Elastic bounce with high speed kickback
      puck.vx = -puck.vx * 1.1 + nx * 2.2;
      puck.vy = puck.vy * 0.4 + g.vy * 0.6 + ny * 1.5;

      // Is it a Save? If the puck was moving towards the goalie's goal line
      if (g.side === 'left' && puck.vx > 0) {
        // Left Goalie saved! Credit the player on that side? No, it's a goalie save.
        // Let's increment team saves
        const opponent = Object.values(state.players).find(p => p.side === 'right');
        if (opponent) {
          // Left goalie saved right player's shot!
          // We can record left goalie saves
        }
      } else if (g.side === 'right' && puck.vx < 0) {
        // Right Goalie saved!
      }

      if (onSoundTrigger) onSoundTrigger('save');
    }
  });
}
