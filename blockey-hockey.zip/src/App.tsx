import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { Volume2, VolumeX, Trophy, Shield, HelpCircle, User, Zap, Users, ShieldAlert, Award } from 'lucide-react';
import { RinkCanvas } from './components/RinkCanvas';
import { CharacterPreview } from './components/CharacterPreview';
import { MatchState, PlayerState, SkinConfig, STICK_SKINS, OUTFIT_COLORS, HEADWEAR_OPTIONS, Side } from './types';
import { createPlayer, updatePhysics, resetPositions, createInitialPuck, createInitialGoalie, RINK_WIDTH, RINK_HEIGHT } from './gamePhysics';
import { audio } from './lib/audio';

export default function App() {
  // LOBBY & CUSTOMIZATION STATES
  const [playerName, setPlayerName] = useState(() => {
    return localStorage.getItem('blockey_hockey_name') || 'Steve';
  });

  const [stickId, setStickId] = useState(() => {
    return localStorage.getItem('blockey_hockey_stick') || 'wood';
  });

  const [outfitId, setOutfitId] = useState(() => {
    return localStorage.getItem('blockey_hockey_outfit') || 'red';
  });

  const [headwearId, setHeadwearId] = useState(() => {
    return localStorage.getItem('blockey_hockey_headwear') || 'none';
  });

  // GAME MODES
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'ended'>('menu');
  const [gameMode, setGameMode] = useState<'practice' | 'local' | 'online'>('practice');
  const [botOpponentActive, setBotOpponentActive] = useState(true);

  // NETWORKING & SOCKET STATES
  const [socket, setSocket] = useState<Socket | null>(null);
  const [socketConnected, setSocketConnected] = useState(false);
  const [queueStatus, setQueueStatus] = useState<{ inQueue: boolean; queuePosition?: number }>({ inQueue: false });
  const [myPlayerId, setMyPlayerId] = useState<string>('p1');
  const [opponentName, setOpponentName] = useState<string>('Opponent');
  const [opponentDisconnected, setOpponentDisconnected] = useState(false);
  const [side, setSide] = useState<Side | null>(null);

  // CORE MATCH STATE FOR CANVAS RENDER
  const [matchState, setMatchState] = useState<MatchState | null>(null);

  // AUTOMATIC INSTANT GOAL REPLAY CLIP BUFFER
  const replayBufferRef = useRef<MatchState[]>([]);
  const [lastGoalReplay, setLastGoalReplay] = useState<MatchState[] | null>(null);
  const [isReplaying, setIsReplaying] = useState(false);
  const [replayFrameIndex, setReplayFrameIndex] = useState(0);
  const [showReplayModal, setShowReplayModal] = useState(false);
  const replayIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // AUDIO STATE
  const [isMuted, setIsMuted] = useState(false);

  // REFS FOR GAME CONTROLS & TIMERS
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const mousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const mouseClickTriggeredRef = useRef<boolean>(false);
  const powerLevelRef = useRef<number>(1);
  const localLoopIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const networkSendIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Save customization changes locally
  useEffect(() => {
    localStorage.setItem('blockey_hockey_name', playerName);
    localStorage.setItem('blockey_hockey_stick', stickId);
    localStorage.setItem('blockey_hockey_outfit', outfitId);
    localStorage.setItem('blockey_hockey_headwear', headwearId);
  }, [playerName, stickId, outfitId, headwearId]);

  // Handle browser audio setup
  const toggleMuted = () => {
    const nextMuted = audio.toggleMute();
    setIsMuted(nextMuted);
  };

  // Keyboard and Window Listeners for Player Controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent scrolling with arrows/space/numbers in game mode
      if (gameState === 'playing' && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'Digit1', 'Digit2', 'Digit3'].includes(e.code)) {
        e.preventDefault();
      }
      keysRef.current[e.code] = true;

      // Quick local power change hotkeys
      if (gameState === 'playing') {
        if (e.code === 'KeyQ') {
          // Toggle local P1 power level
          const currentPower = powerLevelRef.current;
          const nextPower = currentPower === 3 ? 1 : currentPower + 1;
          powerLevelRef.current = nextPower;
          audio.playHit();
        } else if (e.code === 'Digit1' || e.key === '1') {
          powerLevelRef.current = 1;
          audio.playHit();
        } else if (e.code === 'Digit2' || e.key === '2') {
          powerLevelRef.current = 2;
          audio.playHit();
        } else if (e.code === 'Digit3' || e.key === '3') {
          powerLevelRef.current = 3;
          audio.playHit();
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState]);

  // Clean up any running intervals on unmount
  useEffect(() => {
    return () => {
      stopLocalGameLoop();
      stopNetworkSendLoop();
      if (socket) {
        socket.disconnect();
      }
    };
  }, [socket]);

  // Rolling instant replay frame recorder
  useEffect(() => {
    if (!matchState) return;

    if (matchState.status === 'playing') {
      const copy = JSON.parse(JSON.stringify(matchState));
      replayBufferRef.current.push(copy);
      if (replayBufferRef.current.length > 150) {
        replayBufferRef.current.shift();
      }
    } else if (matchState.status === 'goal_scored') {
      if (replayBufferRef.current.length > 0) {
        const captured = [...replayBufferRef.current];
        setLastGoalReplay(captured);
        replayBufferRef.current = []; // Clear for next goal
        setIsReplaying(true);
        setReplayFrameIndex(0);
      }
    }
  }, [matchState]);

  // Goal replay playback clock
  useEffect(() => {
    if (!isReplaying || !lastGoalReplay || lastGoalReplay.length === 0) {
      if (replayIntervalRef.current) {
        clearInterval(replayIntervalRef.current);
        replayIntervalRef.current = null;
      }
      return;
    }

    replayIntervalRef.current = setInterval(() => {
      setReplayFrameIndex((prev) => {
        if (prev + 1 >= lastGoalReplay.length) {
          return 0; // Loop playback
        }
        return prev + 1;
      });
    }, 28); // Playback at smooth ~35 FPS slow-motion

    return () => {
      if (replayIntervalRef.current) {
        clearInterval(replayIntervalRef.current);
        replayIntervalRef.current = null;
      }
    };
  }, [isReplaying, lastGoalReplay]);

  // 1. OFFLINE LOCAL GAME LOOP RUNNER
  const startLocalGameLoop = (mode: 'practice' | 'local') => {
    stopLocalGameLoop();
    keysRef.current = {};
    powerLevelRef.current = 1;

    const mySkinConfig: SkinConfig = { stickId, outfitId, headwearId };
    const p1 = createPlayer('p1', playerName || 'Steve', 'left', mySkinConfig, false);
    
    let playersMap: { [id: string]: PlayerState } = { p1 };

    if (mode === 'local') {
      const p2Skin: SkinConfig = { stickId: 'stone', outfitId: 'blue', headwearId: 'helmet_iron' };
      const p2 = createPlayer('p2', 'Friend', 'right', p2Skin, false);
      playersMap['p2'] = p2;
    } else if (mode === 'practice' && botOpponentActive) {
      // Spawn Practice Computer Bot Opponent
      const botSkin: SkinConfig = { stickId: 'iron', outfitId: 'purple', headwearId: 'helmet_gold' };
      const p2 = createPlayer('bot', 'Creeper Bot', 'right', botSkin, false);
      playersMap['bot'] = p2;
    }

    const initialLocalState: MatchState = {
      roomId: 'offline_room',
      players: playersMap,
      puck: createInitialPuck(),
      goalies: {
        left: createInitialGoalie('left'),
        right: createInitialGoalie('right'),
      },
      score: { left: 0, right: 0 },
      timeLeft: 90, // 90 seconds local play
      status: 'warmup',
      goalScoredTeam: null,
      resetTimer: 3.0,
      winnerId: null,
      gameMode: mode,
    };

    setMatchState(initialLocalState);
    setGameState('playing');
    setGameMode(mode);

    // Track state in local reference inside loop
    let currentLocalState = JSON.parse(JSON.stringify(initialLocalState));
    
    // Client-side local control loops (50 Ticks per second -> 20ms)
    localLoopIntervalRef.current = setInterval(() => {
      const inputs: { [id: string]: { dx: number; dy: number; angle: number; isSwinging: boolean; power: number } } = {};

      // Player 1 input mapping (WASD keys + Mouse)
      let dx1 = 0;
      let dy1 = 0;
      if (keysRef.current['KeyW']) dy1 = -1;
      if (keysRef.current['KeyS']) dy1 = 1;
      if (keysRef.current['KeyA']) dx1 = -1;
      if (keysRef.current['KeyD']) dx1 = 1;

      // Mouse Aim for Player 1
      const p1Obj = currentLocalState.players['p1'];
      let angle1 = p1Obj ? p1Obj.angle : 0;
      if (p1Obj) {
        angle1 = Math.atan2(mousePosRef.current.y - p1Obj.y, mousePosRef.current.x - p1Obj.x);
      }

      inputs['p1'] = {
        dx: dx1,
        dy: dy1,
        angle: angle1,
        isSwinging: mouseClickTriggeredRef.current,
        power: powerLevelRef.current,
      };

      // Reset mouse click trigger after processing
      mouseClickTriggeredRef.current = false;

      // Player 2 or Bot input mapping
      if (mode === 'local') {
        // Same-keyboard Player 2 (Arrow keys + Enter swing + Period power)
        let dx2 = 0;
        let dy2 = 0;
        if (keysRef.current['ArrowUp']) dy2 = -1;
        if (keysRef.current['ArrowDown']) dy2 = 1;
        if (keysRef.current['ArrowLeft']) dx2 = -1;
        if (keysRef.current['ArrowRight']) dx2 = 1;

        const p2Obj = currentLocalState.players['p2'];
        let angle2 = p2Obj ? p2Obj.angle : Math.PI;

        if (p2Obj) {
          // Pure Keyboard auto-targeting puck for Player 2 (No mouse collision!)
          const puck = currentLocalState.puck;
          const distToPuck = Math.hypot(puck.x - p2Obj.x, puck.y - p2Obj.y);
          if (distToPuck < 180) {
            angle2 = Math.atan2(puck.y - p2Obj.y, puck.x - p2Obj.x);
          } else {
            // Face current movement direction
            if (dx2 !== 0 || dy2 !== 0) {
              angle2 = Math.atan2(dy2, dx2);
            }
          }
        }

        // Space / Shift triggers swing for Player 2
        let p2Swinging = false;
        if (keysRef.current['Enter'] || keysRef.current['Space']) {
          p2Swinging = true;
          keysRef.current['Enter'] = false; // Reset instant tap
          keysRef.current['Space'] = false;
        }

        // Period triggers Player 2 power level cycle
        let p2Power = p2Obj ? p2Obj.power : 1;
        if (keysRef.current['Period'] || keysRef.current['KeyM']) {
          p2Power = p2Power === 3 ? 1 : p2Power + 1;
          keysRef.current['Period'] = false;
          keysRef.current['KeyM'] = false;
          audio.playHit();
        }

        inputs['p2'] = {
          dx: dx2,
          dy: dy2,
          angle: angle2,
          isSwinging: p2Swinging,
          power: p2Power,
        };
      } else if (mode === 'practice' && botOpponentActive && currentLocalState.players['bot']) {
        // CPU Bot AI (Smart Chaser: clears corners, targets player goal, swings stick, doesn't get trapped)
        const bot = currentLocalState.players['bot'];
        const puck = currentLocalState.puck;

        const dxBot = puck.x - bot.x;
        const dyBot = puck.y - bot.y;
        const distBot = Math.hypot(dxBot, dyBot);

        let dx_b = 0;
        let dy_b = 0;
        let botAngle = Math.PI;
        let botSwinging = false;

        // Check if puck is in any of the 4 corners of the rink
        const isPuckInTopLeft = puck.x < 150 && puck.y < 120;
        const isPuckInBottomLeft = puck.x < 150 && puck.y > 380;
        const isPuckInTopRight = puck.x > 850 && puck.y < 120;
        const isPuckInBottomRight = puck.x > 850 && puck.y > 380;
        const isPuckInCorner = isPuckInTopLeft || isPuckInBottomLeft || isPuckInTopRight || isPuckInBottomRight;

        if (isPuckInCorner) {
          // Determine the target coordinate to get "behind" the puck (closer to the corner walls than the puck)
          let targetX = puck.x;
          let targetY = puck.y;
          
          if (isPuckInTopLeft) {
            targetX = Math.max(15 + 15, puck.x - 12);
            targetY = Math.max(35 + 15, puck.y - 12);
          } else if (isPuckInBottomLeft) {
            targetX = Math.max(15 + 15, puck.x - 12);
            targetY = Math.min(465 - 15, puck.y + 12);
          } else if (isPuckInTopRight) {
            targetX = Math.min(985 - 15, puck.x + 12);
            targetY = Math.max(35 + 15, puck.y - 12);
          } else if (isPuckInBottomRight) {
            targetX = Math.min(985 - 15, puck.x + 12);
            targetY = Math.min(465 - 15, puck.y + 12);
          }

          const dxToTarget = targetX - bot.x;
          const dyToTarget = targetY - bot.y;
          const distToTarget = Math.hypot(dxToTarget, dyToTarget);

          if (distToTarget > 12) {
            dx_b = Math.sign(dxToTarget);
            dy_b = Math.sign(dyToTarget);
          } else {
            // We are behind the puck! Push towards the center / opponent's side
            dx_b = Math.sign(500 - bot.x);
            dy_b = Math.sign(250 - bot.y);
          }

          // Face the opponent's goal (target is Left Goal at x=60, y=250) to clear it cleanly out of corners
          if (distBot < 55) {
            botAngle = Math.atan2(250 - bot.y, 60 - bot.x);
            botSwinging = true; // Swing aggressively to clear the puck out of the corner
          } else {
            botAngle = Math.atan2(puck.y - bot.y, puck.x - bot.x);
          }
        } else {
          // Standard chase behavior (closer minimum distance of 18px instead of 40px so it doesn't freeze)
          if (distBot > 18) {
            dx_b = Math.sign(dxBot);
            dy_b = Math.sign(dyBot);
          }
          botAngle = Math.atan2(puck.y - bot.y, puck.x - bot.x);
          if (distBot < 45 && Math.random() < 0.25) {
            botSwinging = true;
          }
        }

        // Randomly select power levels for fun
        const botPower = distBot > 180 ? 3 : distBot > 90 ? 2 : 1;

        inputs['bot'] = {
          dx: dx_b,
          dy: dy_b,
          angle: botAngle,
          isSwinging: botSwinging,
          power: botPower,
        };
      }

      // 2. RUN SHARED PHYSICS TICK (Sync sound effects locally!)
      updatePhysics(currentLocalState, inputs, (soundType) => {
        const sounds: { [key: string]: () => void } = {
          hit: () => audio.playHit(),
          shoot: () => audio.playShoot(powerLevelRef.current),
          goal: () => audio.playGoal(),
          post: () => audio.playPost(),
          check: () => audio.playCheck(),
          save: () => audio.playSave(),
        };
        if (sounds[soundType]) {
          sounds[soundType]();
        }
      });

      // Update Render State
      setMatchState({ ...currentLocalState });

      // Handle Game End
      if (currentLocalState.status === 'ended') {
        stopLocalGameLoop();
        setGameState('ended');
      }
    }, 20);
  };

  const stopLocalGameLoop = () => {
    if (localLoopIntervalRef.current) {
      clearInterval(localLoopIntervalRef.current);
      localLoopIntervalRef.current = null;
    }
  };

  // 2. ONLINE REAL-TIME SOCKET.IO CLIENT
  const startOnlineMatchmaking = () => {
    setGameState('menu');
    setGameMode('online');
    setOpponentDisconnected(false);

    // Lazy load socket client on request
    const origin = window.location.origin;
    const socketClient = io(origin);

    setSocket(socketClient);

    socketClient.on('connect', () => {
      console.log('Socket client connected:', socketClient.id);
      setSocketConnected(true);

      const mySkinConfig: SkinConfig = { stickId, outfitId, headwearId };
      socketClient.emit('join_queue', { name: playerName || 'Steve', skinConfig: mySkinConfig });
    });

    socketClient.on('queue_status', (status: { inQueue: boolean; queuePosition?: number }) => {
      setQueueStatus(status);
    });

    socketClient.on('match_start', (data: { side: Side; opponentName: string; state: MatchState }) => {
      console.log('Online Match Started! Assigned Side:', data.side);
      setSide(data.side);
      setMyPlayerId(socketClient.id || 'me');
      setOpponentName(data.opponentName);
      setMatchState(data.state);
      setGameState('playing');
      setQueueStatus({ inQueue: false });
      audio.playGoal(); // Play whistle to start match!

      // Start input synchronization loops (send player updates at 50 FPS)
      startNetworkSendLoop(socketClient);
    });

    socketClient.on('match_update', (serverState: MatchState) => {
      setMatchState(serverState);
    });

    socketClient.on('sound_trigger', (data: { soundType: 'hit' | 'shoot' | 'goal' | 'post' | 'check' | 'save' }) => {
      const currentPower = powerLevelRef.current;
      const sounds: { [key: string]: () => void } = {
        hit: () => audio.playHit(),
        shoot: () => audio.playShoot(currentPower),
        goal: () => audio.playGoal(),
        post: () => audio.playPost(),
        check: () => audio.playCheck(),
        save: () => audio.playSave(),
      };
      if (sounds[data.soundType]) {
        sounds[data.soundType]();
      }
    });

    socketClient.on('opponent_disconnected', () => {
      setOpponentDisconnected(true);
      audio.playGoal();
    });

    socketClient.on('match_end', (finalState: MatchState) => {
      setMatchState(finalState);
      setGameState('ended');
      stopNetworkSendLoop();
    });

    socketClient.on('disconnect', () => {
      setSocketConnected(false);
      setQueueStatus({ inQueue: false });
    });
  };

  const startNetworkSendLoop = (connectedSocket: Socket) => {
    stopNetworkSendLoop();

    networkSendIntervalRef.current = setInterval(() => {
      if (!connectedSocket.connected) return;

      // Pack keys for movement
      let dx = 0;
      let dy = 0;
      if (keysRef.current['KeyW'] || keysRef.current['ArrowUp']) dy = -1;
      if (keysRef.current['KeyS'] || keysRef.current['ArrowDown']) dy = 1;
      if (keysRef.current['KeyA'] || keysRef.current['ArrowLeft']) dx = -1;
      if (keysRef.current['KeyD'] || keysRef.current['ArrowRight']) dx = 1;

      // Calculate stick target angle (mouse relative to visual canvas center)
      const canvasElem = document.getElementById('hockey-rink-canvas');
      let angle = 0;
      if (canvasElem) {
        const rect = canvasElem.getBoundingClientRect();
        // Fallback or estimated player location (P1 is Left, P2 is Right)
        const visualPlayerX = RINK_WIDTH * (myPlayerId === 'left' ? 0.25 : 0.75);
        const visualPlayerY = RINK_HEIGHT / 2;
        
        // Find exact client pixel coordinate on canvas
        const canvasMouseX = (mousePosRef.current.x);
        const canvasMouseY = (mousePosRef.current.y);

        angle = Math.atan2(canvasMouseY - visualPlayerY, canvasMouseX - visualPlayerX);
      }

      connectedSocket.emit('player_input', {
        dx: dx,
        dy: dy,
        angle: angle,
        isSwinging: mouseClickTriggeredRef.current,
        power: powerLevelRef.current,
      });

      // Clear click swing locally
      mouseClickTriggeredRef.current = false;
    }, 20); // 50hz update
  };

  const stopNetworkSendLoop = () => {
    if (networkSendIntervalRef.current) {
      clearInterval(networkSendIntervalRef.current);
      networkSendIntervalRef.current = null;
    }
  };

  const cancelMatchmaking = () => {
    if (socket) {
      socket.emit('leave_queue');
      socket.disconnect();
    }
    setSocket(null);
    setQueueStatus({ inQueue: false });
    setGameMode('practice');
  };

  // Exit current play and return back to customization lobby
  const returnToLobby = () => {
    stopLocalGameLoop();
    stopNetworkSendLoop();
    if (socket) {
      socket.disconnect();
      setSocket(null);
    }
    setGameState('menu');
  };

  // Canvas Mouse Move handler
  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = e.currentTarget;
    const rect = canvas.getBoundingClientRect();
    
    // Scale client coordinate to fit 1000x500 canvas coordinates
    const scaleX = RINK_WIDTH / rect.width;
    const scaleY = RINK_HEIGHT / rect.height;

    mousePosRef.current = {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  // Click shoots puck
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    mouseClickTriggeredRef.current = true;
  };

  // Right-click toggles stick power levels
  const handleCanvasRightClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const currentPower = powerLevelRef.current;
    const nextPower = currentPower === 3 ? 1 : currentPower + 1;
    powerLevelRef.current = nextPower;
    audio.playHit();
  };

  // Quick state details helper
  const getPowerColorClass = (power: number) => {
    if (power === 3) return 'text-red-500 font-bold';
    if (power === 2) return 'text-yellow-500 font-bold';
    return 'text-green-500 font-bold';
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between font-sans selection:bg-cyan-500 selection:text-slate-900">
      
      {/* HEADER SECTION */}
      <header className="bg-slate-900/80 backdrop-blur border-b border-slate-800 py-3 px-6 flex justify-between items-center shadow-lg sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-tr from-cyan-600 to-indigo-600 p-2 rounded-lg border-2 border-cyan-400/30">
            <Trophy className="w-6 h-6 text-cyan-300 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-mono tracking-widest text-cyan-400 font-black">BLOCKEY HOCKEY</h1>
            <p className="text-xs text-slate-400 font-mono">Minecraft Voxel Ice Rink Simulation</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={toggleMuted}
            className="p-2 bg-slate-800 hover:bg-slate-700 active:scale-95 transition border border-slate-700 rounded-lg text-slate-300 hover:text-cyan-400 shadow cursor-pointer"
            title={isMuted ? 'Unmute game sound' : 'Mute game sound'}
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-green-400" />}
          </button>
          
          <div className="text-xs bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-md font-mono text-slate-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-ping"></span>
            Server Port: <span className="text-cyan-400 font-bold">3000</span>
          </div>
        </div>
      </header>

      {/* CORE WRAPPER CONTAINER */}
      <main className="flex-grow flex flex-col justify-center items-center px-4 py-6 max-w-7xl mx-auto w-full">
        
        {/* ========================================================= */}
        {/* SCREEN 1: LOBBY & CUSTOMIZATION MENU                       */}
        {/* ========================================================= */}
        {gameState === 'menu' && (
          <div className="w-full max-w-5xl bg-slate-900 border-4 border-slate-800 rounded-xl p-6 shadow-2xl relative overflow-hidden flex flex-col gap-6 md:grid md:grid-cols-12 md:gap-8">
            <div className="absolute top-0 right-0 p-24 bg-gradient-to-b from-cyan-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 p-24 bg-gradient-to-t from-indigo-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

            {/* Customization Left Column (Voxel Options) */}
            <div className="md:col-span-8 flex flex-col gap-5 relative z-10">
              <div className="border-b border-slate-800 pb-3">
                <h2 className="text-lg font-mono font-bold text-cyan-400 flex items-center gap-2">
                  <User className="w-5 h-5" /> CHARACTER CREATOR
                </h2>
                <p className="text-xs text-slate-400">Design your block skin and choose your stick gear before heading onto the ice</p>
              </div>

              {/* Name Input */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-mono tracking-wider text-slate-300 font-semibold uppercase">Player Name</label>
                <input
                  type="text"
                  maxLength={12}
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="bg-slate-950/90 border-2 border-slate-700 rounded-lg px-4 py-2 text-slate-100 font-mono tracking-widest text-lg focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 shadow-inner"
                  placeholder="Steve"
                />
              </div>

              {/* Outfit Color Selector */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-mono tracking-wider text-slate-300 font-semibold uppercase">Jersey Outfit Color</label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {OUTFIT_COLORS.map((o) => (
                    <button
                      key={o.id}
                      onClick={() => { setOutfitId(o.id); audio.playHit(); }}
                      style={{ backgroundColor: o.primary }}
                      className={`h-12 rounded-lg flex flex-col justify-end p-1 transition-all relative cursor-pointer group active:scale-95 ${
                        outfitId === o.id ? 'ring-4 ring-cyan-400 border-2 border-slate-950 scale-105' : 'hover:scale-102 border-2 border-transparent'
                      }`}
                    >
                      <span className="text-[9px] font-mono font-semibold tracking-tighter text-white bg-black/60 px-1 rounded-sm block w-full truncate text-center">
                        {o.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Stick Skin Selector */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-mono tracking-wider text-slate-300 font-semibold uppercase">Stick Gear Skin</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {STICK_SKINS.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => { setStickId(s.id); audio.playHit(); }}
                      className={`flex items-center gap-2.5 px-3 py-2 bg-slate-950 hover:bg-slate-800/80 rounded-lg text-left border-2 transition active:scale-95 cursor-pointer ${
                        stickId === s.id ? 'border-cyan-400 bg-slate-800' : 'border-slate-800'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full border border-slate-950" style={{ backgroundColor: s.color }} />
                      <span className="text-xs font-mono text-slate-200">{s.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Headwear Options */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-mono tracking-wider text-slate-300 font-semibold uppercase">Helmet / Headwear</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {HEADWEAR_OPTIONS.map((h) => (
                    <button
                      key={h.id}
                      onClick={() => { setHeadwearId(h.id); audio.playHit(); }}
                      className={`flex items-center gap-2.5 px-3 py-2 bg-slate-950 hover:bg-slate-800/80 rounded-lg text-left border-2 transition active:scale-95 cursor-pointer ${
                        headwearId === h.id ? 'border-cyan-400 bg-slate-800' : 'border-slate-800'
                      }`}
                    >
                      <span className="text-base">{h.id === 'none' ? '👤' : '🛡️'}</span>
                      <span className="text-xs font-mono text-slate-200 truncate">{h.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Customization Right Column (Avatar & Play Launchers) */}
            <div className="md:col-span-4 flex flex-col gap-5 items-stretch justify-between bg-slate-950/40 p-4 border border-slate-800 rounded-lg">
              <div className="flex flex-col items-center">
                <h3 className="text-xs font-mono text-slate-400 tracking-wider font-semibold uppercase mb-3">Voxel Preview</h3>
                <CharacterPreview skinConfig={{ stickId, outfitId, headwearId }} name={playerName} />
              </div>

              {/* PLAY ACTIONS BUTTONS */}
              <div className="flex flex-col gap-3">
                {/* PRACTICE MODE */}
                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => { audio.playGoal(); startLocalGameLoop('practice'); }}
                    className="w-full py-3 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 active:scale-98 transition rounded-lg font-mono font-black text-white text-sm tracking-widest shadow-lg flex items-center justify-center gap-2 cursor-pointer border-b-4 border-emerald-800"
                  >
                    <Zap className="w-4 h-4 text-yellow-300 fill-yellow-300" /> PRACTICE MODE
                  </button>
                  
                  {/* Practice Bot Toggle */}
                  <div className="flex items-center justify-between px-2 py-1 bg-slate-950 rounded-md border border-slate-800 text-[11px] font-mono text-slate-400">
                    <span>Spawn AI Practice Bot Opponent</span>
                    <button
                      onClick={() => setBotOpponentActive(!botOpponentActive)}
                      className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase cursor-pointer ${
                        botOpponentActive ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {botOpponentActive ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>
                </div>

                {/* PLAY VS FRIEND */}
                <button
                  onClick={() => { audio.playGoal(); startLocalGameLoop('local'); }}
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 active:scale-98 transition rounded-lg font-mono font-black text-white text-sm tracking-widest shadow-lg flex items-center justify-center gap-2 cursor-pointer border-b-4 border-indigo-800"
                >
                  <Users className="w-4 h-4 text-cyan-300" /> PLAY VS FRIEND (Same PC)
                </button>

                {/* 1V1 ONLINE MATCHMAKING */}
                <div className="relative">
                  {queueStatus.inQueue ? (
                    <div className="bg-slate-950 border-2 border-cyan-400 rounded-lg p-3 text-center flex flex-col gap-2">
                      <div className="flex justify-center items-center gap-2 text-xs font-mono text-cyan-400 font-bold animate-pulse">
                        <span className="w-2.5 h-2.5 bg-cyan-400 rounded-full animate-ping" />
                        SEARCHING OPPONENT...
                      </div>
                      <p className="text-[11px] font-mono text-slate-400">Position in lobby queue: <span className="text-white font-bold">{queueStatus.queuePosition || 1}</span></p>
                      <button
                        onClick={cancelMatchmaking}
                        className="py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded text-[11px] font-mono cursor-pointer"
                      >
                        Cancel Matchmaking
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={startOnlineMatchmaking}
                      className="w-full py-3.5 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 active:scale-98 transition rounded-lg font-mono font-black text-white text-sm tracking-widest shadow-lg flex items-center justify-center gap-2 cursor-pointer border-b-4 border-cyan-800"
                    >
                      <Trophy className="w-4 h-4 text-yellow-300" /> 1V1 ONLINE MULTIPLAYER
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* SCREEN 2: GAMEPLAY ACTIVE CANVAS                           */}
        {/* ========================================================= */}
        {gameState === 'playing' && matchState && (
          <div className="w-full max-w-5xl flex flex-col gap-4">
            
            {/* SCOREBOARD STATUS HEADER */}
            <div className="grid grid-cols-12 gap-3 items-center bg-slate-900 border-4 border-slate-800 rounded-xl p-4 shadow-xl">
              
              {/* Red Team info */}
              <div className="col-span-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-red-600 border border-red-400 flex items-center justify-center font-mono text-white text-sm font-bold shadow">
                  R
                </div>
                <div>
                  <h4 className="text-sm font-mono font-bold tracking-wider text-slate-200 truncate max-w-[120px]">
                    {gameMode === 'online' && side === 'right' ? opponentName : ((Object.values(matchState.players) as PlayerState[]).find(p => p.side === 'left')?.name || 'Red Team')}
                  </h4>
                  <span className="text-[10px] font-mono text-red-400 uppercase">RED SIDE</span>
                </div>
              </div>

              {/* Interactive Center Score / Clock with goal pulse shake transition */}
              <div className="col-span-4 flex flex-col items-center">
                <div className="flex items-center gap-4 bg-slate-950 px-4 py-1.5 border border-slate-800 rounded-lg shadow-inner">
                  <span className={`text-3xl font-mono text-red-500 font-extrabold transition-all duration-300 ${
                    matchState.status === 'goal_scored' && matchState.goalScoredTeam === 'left' ? 'animate-score-burst text-red-400' : ''
                  }`}>
                    {matchState.score.left}
                  </span>
                  <span className="text-slate-500 font-mono text-lg font-black animate-pulse">:</span>
                  <span className={`text-3xl font-mono text-blue-500 font-extrabold transition-all duration-300 ${
                    matchState.status === 'goal_scored' && matchState.goalScoredTeam === 'right' ? 'animate-score-burst text-blue-400' : ''
                  }`}>
                    {matchState.score.right}
                  </span>
                </div>
                
                {/* Clock Remaining */}
                <div className="mt-1 text-xs font-mono font-bold text-yellow-400">
                  TIME LEFT: {Math.floor(matchState.timeLeft)}s
                </div>

                {/* Manual Watch Last Goal Replay Trigger */}
                {lastGoalReplay && (
                  <button
                    onClick={() => {
                      setReplayFrameIndex(0);
                      setIsReplaying(true);
                      setShowReplayModal(true);
                      audio.playHit();
                    }}
                    className="mt-1.5 px-2.5 py-0.5 bg-cyan-500/10 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/35 rounded text-[10px] font-mono font-bold tracking-wider uppercase transition active:scale-95 cursor-pointer flex items-center justify-center gap-1 shadow"
                  >
                    🎬 Watch Replay
                  </button>
                )}
              </div>

              {/* Blue Team info */}
              <div className="col-span-4 flex items-center justify-end gap-3 text-right">
                <div>
                  <h4 className="text-sm font-mono font-bold tracking-wider text-slate-200 truncate max-w-[120px]">
                    {gameMode === 'online' && side === 'left' ? opponentName : ((Object.values(matchState.players) as PlayerState[]).find(p => p.side === 'right')?.name || (gameMode === 'practice' ? 'Practice Target' : 'Blue Team'))}
                  </h4>
                  <span className="text-[10px] font-mono text-blue-400 uppercase">BLUE SIDE</span>
                </div>
                <div className="w-8 h-8 rounded-md bg-blue-600 border border-blue-400 flex items-center justify-center font-mono text-white text-sm font-bold shadow">
                  B
                </div>
              </div>
            </div>

            {/* REAL-TIME CANVAS STAGE CONTAINER */}
            <div className="relative w-full">
              <RinkCanvas
                state={matchState}
                myPlayerId={gameMode === 'online' ? myPlayerId : 'p1'}
                onMouseMove={handleCanvasMouseMove}
                onCanvasClick={handleCanvasClick}
                onCanvasRightClick={handleCanvasRightClick}
              />

              {/* AUTOMATIC PICTURE-IN-PICTURE GOAL REPLAY VIEWPORT OVERLAY */}
              {matchState.status === 'goal_scored' && lastGoalReplay && isReplaying && (
                <div className="absolute top-[10%] left-[20%] w-[60%] bg-slate-900/95 border-4 border-cyan-400 rounded-xl p-3.5 shadow-[0_0_40px_rgba(34,211,238,0.5)] flex flex-col items-center gap-2.5 z-40 animate-pulse-subtle">
                  <div className="flex justify-between items-center w-full px-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
                      <span className="text-xs font-mono font-bold text-rose-500 tracking-wider">● INSTANT GOAL REPLAY</span>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 font-bold">FRAME {replayFrameIndex + 1}/{lastGoalReplay.length}</span>
                  </div>
                  
                  {/* Replay canvas */}
                  <div className="w-full h-[180px] border border-slate-700 rounded-lg overflow-hidden relative shadow-inner">
                    <RinkCanvas
                      state={lastGoalReplay[replayFrameIndex]}
                      myPlayerId={myPlayerId}
                    />
                    <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-slate-950/15 to-transparent bg-[size:100%_4px]" />
                  </div>
                  
                  <div className="text-[9px] font-mono text-slate-400 uppercase tracking-widest text-center mt-0.5">
                    Slow-mo capture of Team {matchState.goalScoredTeam === 'left' ? 'Red' : 'Blue'}'s final scoring moment!
                  </div>
                </div>
              )}
            </div>

            {/* LOWER IN-GAME HUD PANEL (Controls legend, power togglers, stats) */}
            <div className="bg-slate-900 border-4 border-slate-800 rounded-xl p-4 shadow-xl flex flex-col xl:flex-row justify-between items-center gap-4">
              
              {/* Dynamic instruction legend depending on offline/online mode */}
              <div className="flex flex-col gap-1 text-left">
                <span className="text-[11px] font-mono font-bold uppercase text-cyan-400">Controls Legend</span>
                <p className="text-xs text-slate-400 font-mono leading-relaxed">
                  {gameMode === 'local' ? (
                    <>
                      <span className="text-slate-100 font-semibold">P1 (Red):</span> WASD to Move | Click Canvas to Shoot | Press Keys <span className="text-yellow-400 font-black">1 - 3</span> or Q to toggle Power. <br/>
                      <span className="text-slate-100 font-semibold">P2 (Blue):</span> Arrows to Move | Space/Enter to Shoot | Period (.) to cycle Power.
                    </>
                  ) : (
                    <>
                      Move: <kbd className="px-1.5 py-0.5 bg-slate-950 rounded text-slate-100 border border-slate-700">W</kbd>
                      <kbd className="px-1.5 py-0.5 bg-slate-950 rounded text-slate-100 border border-slate-700 mx-0.5">A</kbd>
                      <kbd className="px-1.5 py-0.5 bg-slate-950 rounded text-slate-100 border border-slate-700">S</kbd>
                      <kbd className="px-1.5 py-0.5 bg-slate-950 rounded text-slate-100 border border-slate-700 ml-0.5">D</kbd> or Arrows. <br/>
                      Aim Stick: <span className="text-cyan-400 font-bold">Move Mouse Cursor</span> over the rink. <br/>
                      Shoot Puck: <span className="text-slate-100 font-semibold">Left-Click Mouse</span> | Change Power: <span className="text-slate-100 font-semibold">Keys '1', '2', '3' / Q Key / Right-Click</span>.
                    </>
                  )}
                </p>
              </div>

              {/* Power level interactive toggle button */}
              {gameMode !== 'local' && (
                <div className="flex items-center gap-3 bg-slate-950 px-4 py-2 border border-slate-800 rounded-lg">
                  <span className="text-xs font-mono text-slate-400">Shoot Power:</span>
                  <div className="flex gap-1.5">
                    {[1, 2, 3].map(pow => (
                      <button
                        key={pow}
                        onClick={() => { powerLevelRef.current = pow; audio.playHit(); }}
                        className={`px-3 py-1 font-mono text-xs font-black rounded border-2 transition-all cursor-pointer ${
                          powerLevelRef.current === pow
                            ? pow === 1 ? 'bg-green-500/20 border-green-500 text-green-400' : pow === 2 ? 'bg-yellow-500/20 border-yellow-500 text-yellow-400' : 'bg-red-500/20 border-red-500 text-red-400 scale-105'
                            : 'bg-slate-800 border-slate-700 text-slate-500 hover:text-slate-300'
                        }`}
                      >
                        {pow}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quit button */}
              <button
                onClick={returnToLobby}
                className="px-4 py-2 bg-rose-600/10 hover:bg-rose-600/20 text-rose-400 border border-rose-600/30 rounded-lg text-xs font-mono font-bold tracking-wider hover:text-rose-300 active:scale-95 transition cursor-pointer shadow-md shrink-0"
              >
                Quit Game
              </button>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* SCREEN 3: POST-GAME SUMMARY WITH STATISTICS                 */}
        {/* ========================================================= */}
        {gameState === 'ended' && matchState && (
          <div className="w-full max-w-3xl bg-slate-900 border-4 border-slate-800 rounded-xl p-6 shadow-2xl relative flex flex-col gap-6">
            <div className="text-center">
              <Award className="w-16 h-16 text-yellow-400 mx-auto mb-2 animate-bounce" />
              <h2 className="text-3xl font-mono font-black tracking-widest text-cyan-400">MATCH FINISHED</h2>
              <p className="text-xs text-slate-400 font-mono mt-1">Final scoreboard results and play statistics</p>
            </div>

            {/* Final score card */}
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 flex justify-center items-center gap-8 max-w-md mx-auto w-full">
              <div className="text-center">
                <span className="text-xs font-mono text-red-400 block mb-1">RED SIDE</span>
                <span className="text-4xl font-mono font-extrabold">{matchState.score.left}</span>
              </div>
              <span className="text-slate-600 font-mono text-2xl">VS</span>
              <div className="text-center">
                <span className="text-xs font-mono text-blue-400 block mb-1">BLUE SIDE</span>
                <span className="text-4xl font-mono font-extrabold">{matchState.score.right}</span>
              </div>
            </div>

            {/* Victory Declarer banner */}
            <div className="py-2.5 px-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-center max-w-md mx-auto w-full font-mono text-cyan-300 text-sm font-bold uppercase">
              {matchState.winnerId === 'tie' ? (
                <span>THE MATCH ENDED IN A DRAW TIE!</span>
              ) : (
                <span>
                  Winner: {
                    matchState.winnerId ? (
                      matchState.players[matchState.winnerId]?.name || 'Champion Player'
                    ) : 'Champion Player'
                  }
                </span>
              )}
            </div>

            {/* Comprehensive Player Performance Stats Table */}
            <div className="flex flex-col gap-2">
              <h3 className="text-xs font-mono text-slate-400 uppercase tracking-widest font-semibold">Game Performance Logs</h3>
              <div className="overflow-x-auto border border-slate-800 rounded-lg">
                <table className="w-full text-left border-collapse font-mono text-xs">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] border-b border-slate-800">
                      <th className="py-2.5 px-4">Player</th>
                      <th className="py-2.5 px-4 text-center">Goals</th>
                      <th className="py-2.5 px-4 text-center">Shots On Goal</th>
                      <th className="py-2.5 px-4 text-center">Power Shots</th>
                      <th className="py-2.5 px-4 text-center">Body Checks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 bg-slate-900/50">
                    {(Object.values(matchState.players) as PlayerState[]).map((p) => (
                      <tr key={p.id} className="hover:bg-slate-800/30">
                        <td className="py-3 px-4 font-bold flex items-center gap-2">
                          <span className={`w-2.5 h-2.5 rounded-sm ${p.side === 'left' ? 'bg-red-500' : 'bg-blue-500'}`} />
                          {p.name}
                        </td>
                        <td className="py-3 px-4 text-center font-bold text-yellow-400 text-sm">{p.stats.goals}</td>
                        <td className="py-3 px-4 text-center">{p.stats.shotsOnGoal}</td>
                        <td className="py-3 px-4 text-center text-red-400 font-semibold">{p.stats.powerShots}</td>
                        <td className="py-3 px-4 text-center text-indigo-300">{p.stats.checks}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Actions button */}
            <button
              onClick={returnToLobby}
              className="py-3 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 transition active:scale-98 rounded-lg font-mono font-black text-white tracking-widest uppercase cursor-pointer border-b-4 border-cyan-800"
            >
              Return to Customization Lobby
            </button>
          </div>
        )}

        {/* MANUAL INSTANT REPLAY MODAL POPUP */}
        {showReplayModal && lastGoalReplay && (
          <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
            <div className="w-full max-w-3xl bg-slate-900 border-4 border-cyan-400 rounded-2xl p-5 shadow-[0_0_50px_rgba(34,211,238,0.25)] flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-200">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 bg-cyan-400 rounded-full animate-ping" />
                  <h3 className="text-base font-mono font-black text-cyan-400 tracking-widest">🎬 INSTANT GOAL REPLAY</h3>
                </div>
                <button
                  onClick={() => {
                    setIsReplaying(false);
                    setShowReplayModal(false);
                    audio.playHit();
                  }}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-md text-xs font-mono font-bold cursor-pointer transition border border-slate-700 active:scale-95 shadow"
                >
                  Close Replay
                </button>
              </div>
              
              <div className="w-full h-[400px] border-2 border-slate-800 rounded-xl overflow-hidden relative shadow-lg bg-slate-950 flex items-center justify-center">
                <RinkCanvas
                  state={lastGoalReplay[replayFrameIndex]}
                  myPlayerId={myPlayerId}
                />
                <div className="absolute top-4 left-4 bg-black/75 border border-slate-700/80 px-2.5 py-1 rounded text-[10px] font-mono text-slate-300 flex items-center gap-1.5 shadow">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  SLOW-MOTION PLAYBACK (35 FPS)
                </div>
              </div>
              
              <div className="flex justify-between items-center px-1">
                <span className="text-xs font-mono text-slate-400 uppercase">Goal Replay Clip Buffer</span>
                <span className="text-xs font-mono text-cyan-400 font-bold">FRAME {replayFrameIndex + 1} / {lastGoalReplay.length}</span>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900/60 border-t border-slate-800 py-3 text-center text-[10px] font-mono text-slate-500 px-4">
        Blockey Hockey Online &copy; 2026. Made with Google AI Studio. Playable via local network.
      </footer>
    </div>
  );
}
